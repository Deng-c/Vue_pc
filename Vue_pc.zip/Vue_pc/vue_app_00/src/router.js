import Vue from 'vue'
import Router from 'vue-router'
import Home from './views/Home.vue'
import HelloContainer from "./components/HelloWorld.vue"
Vue.use(Router)
//2. 为Exam01.vue 配置路径

export default new Router({
  routes: [
    {
      path:'/',
      redirect:'/Home1'
    },
    {
      path:"/loginzc",
      name:'loginzc',
      component:resolve =>require(['./components/cake/common/Login_zc.vue'],resolve)
    },
    {
      path:"/detail",
      name:'detail',
      component:resolve => require(["./components/cake/common/Detail.vue"],resolve)
    },
    {
      path:'/Cart',
      name:'cart',
      component:resolve => require(['./components/cake/common/Cart.vue'],resolve)
    },
    {
      path:'/login',
      name:'login',
      component:resolve =>require(['./components/cake/common/Login.vue'],resolve)
    },
    {
      path:"/footer",
      name:'footer',
      component:resolve =>require(['./components/cake/common/Footer.vue'],resolve)
    },
    {
      path:"/Home1",
      name:'Home1',
      component:resolve =>require(['./components/cake/Home1.vue'],resolve)
    },
    {
      path: '/',
      name: 'home',
      component: Home
    },
    {
      path: '/about',
      name: 'about',
      // route level code-splitting
      // this generates a separate chunk (about.[hash].js) for this route
      // which is lazy-loaded when the route is visited.
      component: () => import(/* webpackChunkName: "about" */ './views/About.vue')
    }
  ]
})
