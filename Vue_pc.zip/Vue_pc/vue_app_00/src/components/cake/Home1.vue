<template>
  <div>
    <!-- 头部组件 -->
    <headerCake></headerCake>    
    <div style="margin-top:80px;"></div>
    <!-- 轮播图 -->
    <carousel></carousel>
    <!-- 内容导航条 -->
    <navigation></navigation>
    <!-- 主体 新品 生日 儿童 聚会 -->
    <product></product>
    <!-- 距离显示 -->
    <div style="margin-top:60px;"></div>
    <!-- 尾部组件 -->
    <footerCake></footerCake>
  </div>
</template>
<script>
import Header_cake from "./common/Header_cake.vue"
import Footer from "./common/Footer.vue"
import Carousel from './common/Carousel.vue'
import Navigation from './common/Navigation.vue'
import NewProduct from './common/NewProduct.vue' 
export default {
  data(){
    return{

    }
  },
  components:{
    "headerCake":Header_cake,
    "footerCake":Footer,
    "carousel" : Carousel,
    "navigation": Navigation,
    "product" : NewProduct,
  }
}
</script>
<style scoped>

</style>
