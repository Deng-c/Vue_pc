<template>
  <div>23
    <headerCake></headerCake>
    <div style="margin-top:80px;"></div>
    <!-- 登录 -->
    <div class="login">
      <div>
        <div>
          <h2>账号密码登录</h2>
          <h2>手机验证码登录</h2>
        </div>
        <!-- 账号密码登录 -->
        <div class="login_pwd">
          <form action="">
            <ul>
              <li>
                <input type="text" v-model="uname" placeholder="请输入您的账号">
            
              </li>
              <li>
                <input type="password" v-model="upwd" placeholder="请输入您的密码">
          
              </li>
              <li><button @click="login">登录</button></li>
              <li>
                <router-link to=""><input type="checkbox" checked>&nbsp; 记住账号</router-link>
                <router-link to="">忘记密码</router-link>
                <router-link to="Loginzc">去注册</router-link>
              </li>
            </ul>
          </form>
        </div>
        <!-- 手机验证码登录 -->
        <div></div>
      </div>
    </div>
    <footer1></footer1>
  </div>
</template>
<script>
import HeaderCake from './Header_cake.vue'
import Footer from './Footer.vue'
export default {
  data(){
    return{
      uname:'',
      upwd:''
    }
  },
  methods:{
    login(){
      var u = this.uname;
      var p = this.upwd;
      //发送ajax请求
      //发送ajax请求
      var url ="login";
      var obj = {uname:u,upwd:p};
      console.log(obj);
      this.axios.get(url,{params:obj}).then(result=>{console.log(result);
      // 正确跳转Home组件
      if(result.data.code>0){
        this.$router.push('../Home1')
      }else{
        alert("提示,用户名或密码有误")
      }
    })
    }
  },
  components:{
    "headerCake":HeaderCake,
    'footer1':Footer
  }
}
</script>
<style scoped>
a{
  display: inline-block
}
/* 登录form位置调整 */
  .login{
    background:url(../../../assets/passport-banner.jpg) no-repeat top center;
    height:571px;
    width:100%;
    min-width:1128px;
  }
  .login>div{
    width:302px;
    position: relative;
    top:114px;
    right:-650px;
    padding:28px 42px;
    border: 1px solid #e9e9e9;
  }
  .login>div>div>h2{
    width:150px;
    font-size:18px;
    font-weight: 500;
    text-align: center;
    display: inline-block;
  }
  .login>div>div>h2:first-child{
    border-right: 1px solid #dcdcdc;
  }
  .login>div>div>h2:last-child{
    border-left: 1px solid #dcdcdc;
  }
  /* 账号登录 */
  .login_pwd{
    padding-top:15px;
    background:#fff;
  }
  .login_pwd>form>ul>li{
    margin:10px 0;
  }
  /* 账号密码 */
  .login_pwd>form>ul>li>input{
    width:290px;
    height:36px;
    line-height: 38px;
    color:#442818;
    padding:0 5px;
    border-radius: 3px;
    border:1px solid #e9e9e9;
  }
  /* 登录按钮 */
  .login_pwd>form>ul>li>button{
    width:302px;
    height:48px;
    font-size:18px;
    border-radius: 2px;
    border:0;
    margin-top:32px;
    text-align: center;
    background:#442818;
    color:#fff;
  }
  /* 忘记密码项 */
  .login_pwd>form>ul>li:last-child{
    padding-top:5px;
    padding-bottom: 40px;
  }
  .login_pwd>form>ul>li>a{
    font-size: 12px;
    color:#684029;
    height: 18px;
    line-height: 18px;
    display: inline-block;
  }
  .login_pwd>form>ul>li>a:hover{
    color:#BB9772;
  }
  .login_pwd>form>ul>li>a:last-child,.login_pwd>form>ul>li>a:nth-child(2){
    float: right;
    margin-left:18px;
  }
  .login_pwd>form>ul>li:last-child>a>input{
    display: inline-block;
    vertical-align: middle;
    cursor: pointer;
  }
</style>
