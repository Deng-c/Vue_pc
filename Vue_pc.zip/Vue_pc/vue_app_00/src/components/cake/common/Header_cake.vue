<template>
  <div class="header_0">
    <ul class="header">
      <li><img src="../../../assets/logo2.png" alt=""></li>
      <li>
        <router-link to='Home1'>首页</router-link>
      </li>
      <li>
        <router-link to=''>蛋糕</router-link>
      </li>
      <li>
        <router-link to=''>面包</router-link>
      </li>
      <li>
        <router-link to=''>冰淇淋</router-link>
      </li>
      <li>
        <router-link to=''>咖啡下午茶</router-link>
      </li>
      <li>
        <router-link to=''>全国送</router-link>
      </li>
      <li>
        <router-link to=''>企业专区</router-link>
      </li>
    </ul>
    <!-- login -->
    <div class="header_login">
      <div>
        <router-link to="">APP下载</router-link>
        <!-- 没有些完整 -->
        <!-- <img src="../../../assets/footer-erweima.png" alt=""> -->
      </div>
      <div>
        <router-link to="">上海▼</router-link>
      </div>
      <div>
        <router-link to="">消息</router-link>
      </div>
      <div>
        <router-link to="Login">登录</router-link>/
        <router-link to="Loginzc">注册</router-link>   
      </div>
      <div @click="cart">
        <img src="../../../assets/gwc.png" alt="">
      </div>
    </div>
  </div>
</template>
<script>
export default {
  data(){
    return{}
  },
  methods:{
    cart(){
      this.$router.push("/Cart")
    }
  }
}
</script>
<style scoped>
  *{margin:0;padding:0;position:0;}
  a{text-decoration: none;color:#684029;}
  li{list-style: none;}
  .header_0{
    font-family: 'PingFang SC','Heiti SC','微软雅黑',Helvetica,Arial;
    font-size: 12px;
    color: #684029;
    overflow-x: hidden;
    box-shadow: 0 2px 2px 0 rgba(195,195,195,0.50);
    background:#fff; 
    z-index: 99;
    position: fixed;
    width: 100%;
    height:80px;
    top: 0;
    left: 0;
    min-width: 760px;
  }
  .header{height: 80px;}
  .header>li{
    display: inline-block;
    list-style: none;
    margin:0px 15px;
  }
  .header>li:nth-child(2){
    margin-left:35px;
  }
  .header>li>a{
    text-decoration: none;
    color:#684029;
    font-size:14px;
    outline: none;
    cursor: pointer;
  }
  .header>li>a:hover{
    color:#BB9772;
  }
  .header>li>img{
    width:120px;
    position: relative;
    top:18px;
    box-sizing: border-box;
  }
  /* header_login */
  .header_login{
    height:80px;
    float: right;
    position: relative;
    z-index: 1001;
    top:-80px;
    line-height: 80px;
    font-size:14px;
  }
  .header_login>div{
    float: left;
  }
  /* header_login app下载 */
  .header_login>div:first-child{
    margin-right:20px;
  }
  .header_login>div:nth-child(2){
    width: 84px;
    text-align: center;
  }
  .header_login>div:nth-child(3){
    width: 50px;
    text-align: center;
  }
  .header_login>div:nth-child(4){
    width: 80px;
    text-align: center;
  }
  .header_login>div:last-child{
    width: 39px;
    text-align: center;
  }
  .header_login>div:last-child>img{
    width: 29px;
    margin-top:25px;
    box-sizing: border-box;
  }
  .header_login>div>a:hover{
    color:#BB9772;
  }
  /* hover 样式 */
  .header_login>div>a+img{
    width: 70px;
    position:absolute;
    z-index: 111;
    top:50px;
    left:0%;
    padding:7px;
    box-shadow:0px 0px 5px #ccc;
  }
</style>
