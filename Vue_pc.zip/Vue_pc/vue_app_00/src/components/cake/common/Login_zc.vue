<template>
  <div>
    <headerCake></headerCake>
    <div style="margin-top:80px;"></div>
    <div class="login">
      <div class="login_zc">
        <h2>用户注册</h2>
        <ul>
          <!-- 手机号码 -->
          <li>
            <input type="text" @blur="lose" @focus="lose"  v-model="phone" placeholder="请输入手机号码">
            <p :class="phoneClass">{{phone1}}</p>
          </li>
          <!-- 密码 -->
          <li>
            <input type="password" @blur="losePwd" @focus="losePwd"  v-model="upwd" placeholder="密码：请输入6~12字符">
            <p :class="upwdClass">{{upwd1}}</p>
          </li>
          <!-- 确认密码 -->
          <li>
            <input type="password" @blur="losePwd2" @focus="losePwd2" v-model="upwd2"  placeholder="确认密码">
            <p :class="upwdClass2">{{upwd3}}</p>
          </li>
          <!-- 短信验证 -->
          <li id="code">
            <input type="text" v-model="yanz" placeholder="短信验证码"><button>获取验证码</button>
            </li>
          <li>
            <button @click="login">注册</button>
          </li>
        </ul>
      </div>
    </div>
    <footer1></footer1>
  </div>
</template>
<script>
import HeaderCake from './Header_cake.vue'
import Footer from './Footer.vue'
export default {
  data(){
    return{
      phone:'',
      phone1:'',
      upwd:'',
      upwd1:'',
      upwd2:'',
      upwd3:'',
      yanz:'3425',
      phoneClass:'',
      upwdClass:'',
      upwdClass2:''
    }
  },
  methods:{
    lose(){
    // 手机号验证
      var phone = this.phone;
      var reg =/^1[3-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]$/i;
      if(!reg.test(phone)){
        this.phone1="手机号格式不正确";
        this.phoneClass="error";
        return;
      }else{
        this.phone1 = "手机号正确";
        this.phoneClass="success";
        return;
      }
    },
    losePwd(){
      // 密码验证
      var upwd = this.upwd;
      var reg2 =/^[a-z0-9_A-Z]{6,12}$/i;
      if(upwd.length<6){
        this.upwd1="密码长度不能小于6位";
        this.upwdClass="error";
        return;
      }else if(upwd.length>12){
        this.upwd1 = "密码长度不能超过12位";
        this.upwdClass = "error";
        return;
      }else {
        this.upwd1 = "密码正确"
        this.upwdClass ="success";
        return;
      }
    },
    losePwd2(){
      var upwd = this.upwd;
      var upwd2 = this.upwd2;
      if(upwd=upwd2){
        this.upwd3 = "密码正确";
        this.upwdClass2 ="success";
        return;
      }else{
        this.upwd3 = "密码不一致"
        this.upwdClass2 ="error";
        return;
      }
    },
    login(){
      var url = "loginZc";
      var uname = this.phone;
      var upwd = this.upwd;
      // console.log(uname);
      var obj = {uname,upwd};
      console.log(obj)
      this.axios.get(url,{params:obj}).then(result=>{console.log(result);
      if(result.data.code>0){
        this.$router.push("/Login")
      }else{
        console.log("错误")
      }
      });
    }
  },
  components:{
    "headerCake":HeaderCake,
    'footer1':Footer
  }
}
</script>
<style scoped>
  .login{
    height:571px;
    background:url(../../../assets/passport-banner.jpg) no-repeat top center;
  }
  .login_zc{
    width:303px;
    padding:28px 42px;
    border: 1px solid #e9e9e9;
    position: relative;
    top:114px;
    left:650px;
    text-align: center;
  }
  /* 表单样式 */
  .login_zc>h2{
    font-size:18px;
    color:#482618;
    font-weight: 500;
  }
  .login_zc>ul{
    padding-top:15px;
  }
  .login_zc>ul>li{
    padding:5px 0;
  }
  .login_zc>ul>li>input{
    width:290px;
    height:36px;
    line-height: 38px;
    color:#442818;
    padding:0 5px;
    border-radius: 3px;
    border:1px solid #e9e9e9;
  }
  /* 判断输入样式 */
  .login_zc>ul>li>p{
    display: inline-block;
    position: relative;
    padding: 2px 5px;
    font-size:12px;
    top:-29px;
    left:86px;
  }
  .success{
    color:#0a0;
    background:#cfc;
  }
  .error{
    color:#a00;
    background: #fcc;
  }
  .login_zc>ul>li>button{
    width:302px;
    height:48px;
    line-height: 48px;
    color:#fff;
    font-size:18px;
    padding:0 5px;
    border-radius: 3px;
    border:0;
    background: #442818;
  }
  #code>input{
    width:128px;
  }
  #code>button{
    font-size:12px;
    width:149px;
    height:36px;
    line-height:36px; 
    margin-left:14px;
    border:1px solid #ebebeb;
    background:#fafafa;
    color:#442818;
    border-radius: 3px;
  }
  
</style>
