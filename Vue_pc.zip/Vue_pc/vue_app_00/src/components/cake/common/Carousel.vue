<template>
  <div class="block">
    <el-carousel height="504px" min-width="1200px">
      <el-carousel-item v-for="item in 3" :key="item">
       
      </el-carousel-item>
    </el-carousel>
  </div>
</template>
<style>
  .block{
    min-width:1200px;
  }
  .el-carousel__item:nth-child(2n) {
    background: url(../../../assets/carousel.jpg) no-repeat ;
    width:100%;
    background-position: center center;
    transform: scale(1);
    backface-visibility: hidden;
  }
  .el-carousel__item:nth-child(2n+1) {
    background:url(../../../assets/carousel01.jpg) no-repeat;
    width:100%;
    background-position: center center;
    transform: scale(1);
    backface-visibility: hidden;
  }
  .el-carousel__item:nth-child(2n+2) {
    background:url(../../../assets/qix.jpg) no-repeat;
    width:100%;
    background-position: center center;
    transform: scale(1);
    backface-visibility: hidden;
  }
  .el-carousel__button {
    width: 10px !important;
    height: 10px !important;
    background-color: #684029 !important;
    border-radius: 50%;
  }
</style>