<template>
  <div v-loading="loading">
    <div>
      <!-- 新品专区 -->
      <h4 id="divNode" class="product_header">新品<span>/专区</span></h4>
      <!-- 大图 -->
      <div v-for="(item,i) of list" :key="i" class="cakeMax">
        <el-image v-loading="loading" :src="'http://127.0.0.1:3000/img/NewProduct/'+item.img_url" lazy></el-image>
      </div>
      <!-- 内容 -->
      <div class="NewProduct">
      <div v-for="(item,i) of list2" :key="'01-'+i" class="productTitle" >
          <router-link to="">
            <el-image v-loading="loading" :src="'http://127.0.0.1:3000/img/NewProduct/'+item.img_url" lazy></el-image>
            <h4>{{item.title}}</h4>
            <p>{{item.subtitle}}</p>
            <span>{{item.label01}}</span>
            <span>{{item.label02}}</span>
            <span>{{item.label03}}</span>
          </router-link>
          <div class="price" @click="cartActive(item,i)">
            <span>{{item.price}}</span>
            <!-- 点击购物车 -->
            <router-link to=""  >
              {{item.cart}}
            </router-link>
            <!--  加入购物车  -->
            <div style="position: relative;">
            <div  v-show="item.active" v-bind:class="{'you' : item.active, 'you2': !item.active}" class="cart" >
              <div>{{item.cart_price}}</div>
              <div>
                <span>{{item.cart_title}}</span>
                <span>{{item.cart_title02}}</span>
              </div>
              <div>
                <span>{{item.cart_buy}}</span>
                <span>{{item.cart}}</span>
              </div>
            </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- 生日专区 -->
    <div>
      <h4 id="divNode2" class="product_header">生日<span>/专区</span></h4>
      <!-- 大图 -->
      <div v-for="(item,i) of birthday" :key="'02-'+i" class="cakeMax">
        <el-image v-loading="loading" :src="'http://127.0.0.1:3000/img/NewProduct/'+item.img_url" lazy></el-image>
      </div>
      <!-- 内容 -->
      <div class="NewProduct">
      <div v-for="(item,i) of birthday2" :key="'03-'+i" class="productTitle" >
          <router-link to="">
            <el-image v-loading="loading" :src="'http://127.0.0.1:3000/img/NewProduct/'+item.img_url" lazy></el-image>
            <h4>{{item.title}}</h4>
            <p>{{item.subtitle}}</p>
            <span>{{item.label01}}</span>
            <span>{{item.label02}}</span>
            <span>{{item.label03}}</span>
          </router-link>
          <div class="price">
            <span>{{item.price}}</span>
            <router-link to="">
              {{item.cart}}
            </router-link>
          </div>
        </div>
      </div>
    </div>
    <!-- 儿童专区 -->
    <div>
      <h4 id="divNode3" class="product_header">儿童<span>/专区</span></h4>
      <!-- 大图 -->
      <div v-for="(item,i) of child" :key="'04-'+i" class="cakeMax">
        <el-image v-loading="loading" :src="'http://127.0.0.1:3000/img/NewProduct/'+item.img_url" lazy></el-image>
      </div>
      <!-- 内容 -->
      <div class="NewProduct">
      <div v-for="(item,i) of child2" :key="'05-'+i" class="productTitle" >
          <router-link to="">
            <el-image v-loading="loading" :src="'http://127.0.0.1:3000/img/NewProduct/'+item.img_url" lazy></el-image>
            <h4>{{item.title}}</h4>
            <p>{{item.subtitle}}</p>
            <span>{{item.label01}}</span>
            <span>{{item.label02}}</span>
            <span>{{item.label03}}</span>
          </router-link>
          <div class="price">
            <span>{{item.price}}</span>
            <router-link to="">
              {{item.cart}}
            </router-link>
          </div>
        </div>
      </div>
    </div>
    <!-- 聚会专区 -->
    <div>
      <h4 id="divNode4" class="product_header">聚会<span>/专区</span></h4>
      <!-- 大图 -->
      <div v-for="(item,i) of gathering" :key="'06-'+i" class="cakeMax">
        <el-image v-loading="loading" :src="'http://127.0.0.1:3000/img/NewProduct/'+item.img_url" lazy></el-image>
      </div>
      <!-- 内容 -->
      <div class="NewProduct">
      <div v-for="(item,i) of gathering2" :key="'07-'+i" class="productTitle" >
          <router-link to="">
            <el-image v-loading="loading" :src="'http://127.0.0.1:3000/img/NewProduct/'+item.img_url" lazy></el-image>
            <h4>{{item.title}}</h4>
            <p>{{item.subtitle}}</p>
            <span>{{item.label01}}</span>
            <span>{{item.label02}}</span>
            <span>{{item.label03}}</span>
          </router-link>
          <div class="price">
            <span>{{item.price}}</span>
            <router-link to="">
              {{item.cart}}
            </router-link>
          </div>
        </div>
      </div>
      </div>
      <!-- 活动专区 -->
    <div>
      <h4 id="divNode5" class="product_header">活动门<span>/是被吸引了吧</span></h4>
      <!-- 大图 -->
      <div v-for="(item,i) of activity" :key="'08-'+i" class="activity">
        <el-image v-loading="loading" :src="'http://127.0.0.1:3000/img/NewProduct/'+item.img_url" lazy></el-image>
      </div>
    </div>
    <!-- 文章 -->
    <div>
      <h4 class="product_header">廿一客<span>/文章</span></h4>
      <!-- 大图 -->
      <div class="article">
        <div>
          <img src="../../../assets/jibo.jpg" alt="">
          <p>冬季刊·进博会</p>
          <router-link to=''>阅读全文 >></router-link>
        </div>
        <div>
          <img src="../../../assets/QA.jpg" alt="">
          <p>廿一志秋刊·客服Q&A</p>
          <router-link to="">阅读全文 >></router-link>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  data(){
    return{
      list:[],
      list2:[],
      birthday:[],
      birthday2:[],
      child:[],
      child2:[],
      gathering:[],
      gathering2:[],
      activity:[],
      loading:true,
      // 购物车点击显示
      active:true
    }
  },
  methods:{ 
    loadMore(){
      var url="/cakeMax";
      this.axios.get(url).then(result=>{
        this.list=result.data;
      })
      var url ="/newProduct";
      this.axios.get(url).then(result=>{
        this.list2=result.data;
      })
      // 生日专区
      var url="/cakeMax02";
      this.axios.get(url).then(result=>{
        this.birthday=result.data;
      })
      var url ="/birthday";
      this.axios.get(url).then(result=>{
        this.birthday2=result.data;
      })
      // 儿童专区
      var url="/cakeMax03";
      this.axios.get(url).then(result=>{
        this.child=result.data;
      })
      var url ="/child";
      this.axios.get(url).then(result=>{
        this.child2=result.data;
      })
      // 聚会专区
      var url="/cakeMax04";
      this.axios.get(url).then(result=>{
        this.gathering=result.data;
      })
      var url ="/gathering";
      this.axios.get(url).then(result=>{
        this.gathering2=result.data;
      })
      // 活动专区
      var url="/cakeMax05";
      this.axios.get(url).then(result=>{
        this.activity=result.data;
      })
    },
    // 点击显示 隐藏 加入购物车
    cartActive(item,i){
      console.log(item)
      this.$nextTick(function(){
        this.item.foEach(function(item){
          Vue.set(item,"active",false);
        });
        Vue.set(item,'active',true);
      })
       //获取点击对象      
      var el = i.currentTarget;
      console.log(this.current)
      this.item.acitve=!this.item.acitve;
     
    }
  },
  created(){
    this.loadMore();
    setTimeout(() => {
      this.loading=false;
    },1000);
  }
}
</script>
<style scoped>
  .product_header{
    width:1100px;
    font-size:26px;
    font-weight: 500;
    line-height: 36px;
    padding-top:50px;
    margin:30px auto 10px;
    padding:0 50px;
  }
  .product_header>span{
    font-size: 14px;
  }
  /* cakeMax  大图*/
  .cakeMax{
    width:1100px;
    height:250px;
    margin:0 auto;
    padding:0 50px;
  }
  .cakeMax>img{
    display: inline-block;
  }
  /* NewProduct 内容 */
  .NewProduct{
    width:1116px;
    margin:0 auto;
    padding:0 50px;
  }
  .productTitle{
    display: inline-block;
    
    width:263px;
    margin:0 8px;
    box-sizing: border-box;
  }
  .productTitle>a>img{
    width: 263px;
  }
  .productTitle>a>img:hover{
    transform: scale(1.02);
  }
  .productTitle>a>h4{
    padding-top:10px;
  }
  .productTitle>a>p{
    color:#616161;
    font-size:14px;
    line-height: 24px;
  }
  .productTitle>a>span{
    display: inline-block;
    color:#D5BFA7;
    font-size:12px;
    border:1px solid #D5BFA7;
    border-radius: 100px;
    padding:1px 6px;
    margin:8px 3px;
  }
  /* 价格 购物车 */
  .price{
    border-top:1px dashed #D5BFA7;
    padding-top:14px;
    height: 37px;
  }
  .price>span:first-child{
    font-size:14px;
    color:#b0986f;
  }
  .price>a{
    float: right;
    display: inline-block;
    line-height: 20px;
    color:#fff;
    font-size: 12px;
    background: #643E28;
    padding:2px 10px;
    border-radius: 2px;
  }
  /* 活动专区 */
  .activity{
    width:1116px;
    margin:0 auto;
    padding:0 50px;
  }
  .activity>img{
    height:252px;
    border-radius: 15px;
  }
  .activity>img:hover{
    transform: scale(1.01);
  }
  /* 廿一客/文章 */
  .article{
    width:1116px;
    margin:0 auto;
    padding:0 50px;
  }
  .article>div{
    box-sizing: border-box;
    display: inline-block;
    width:50%;
  }
  .article>div>img{
    border-radius: 15px;
    height:252px;
    width:542px;
  }
  .article>div>img:hover{
    transform: scale(1.01);
  }
  .article>div>p{
    color:#222;
    font-size:24px;
    margin-top:14px;
    padding:0 16px;
  }
  .article>div>a{
    color:#AD814B;
    font-size:14px;
    padding:0 16px;
    line-height: 44px;
  }
  .article>div>a:hover{
    color:#D5BFA7;
  }
  /* 购物车 */
  .cart{
    width:263px;
    background:#fafafa;
    padding:12px;
    position: absolute;
    z-index: 10;
    top:-130px;
  }
  .cart>div:first-child{
    width:239px;
    color:#684029;
    font-size:16px;
  }
  /* span内容样式 */
  .cart>div:nth-child(2){
    width:239px;
    padding:10px 0;
  }
  .cart>div:nth-child(2)>span{
    display: inline-block;
    box-sizing: border-box;
    width: 55px;
    font-size: 12px;
    height: 34px;
    padding: 2px 8px;
    text-align: center;
    margin: 2px;
    color:#7A5844;
    border: 1px solid #D0C3BB;
  }
  .cart>div:nth-child(2)>span:active{
    border: 1px solid #684029;
    color: #684029;
  }
  .cart>div:nth-child(3){
    width: 239px;
    height: 46px;
    font-size: 12px;
  }
  .cart>div:nth-child(3)>span:first-child{
    display: inline-block;
    text-align: center;
    line-height: 30px;
    width: 114px;
    height: 30px;
    margin: 8px 0;
    color: #7A5844;
  }
  .cart>div:nth-child(3)>span:last-child{
    display: inline-block;
    text-align: center;
    line-height: 30px;
    width: 114px;
    height: 30px;
    margin: 8px 0;
    color: #fff;
    background: #684029;
  }
  /* 点击购物车显示隐藏 */
  .you2{
    opacity: 0;
    height:0;
  }
  .you{
    opacity: 1; 
    height:149px;
    transform: translateY(0);
    transition: all 0.2s;
  }
</style>
