<template>
  <div>
    <headerCake></headerCake>
    <div style="margin-top:80px"></div>
    <div class="cart" >
      <img src="../../../assets/gou.png" alt="">
      <span>您的购物车里还没有商品</span>
      <router-link to="../Home1">去购物 >></router-link>
    </div>
    <div>
      <h2>商品推荐</h2>
      <ul class="myCart">
        <li>
          <img src="../../../assets/m-1.jpg" alt="">
        </li>
        <li>
          <img src="../../../assets/m-2.jpg" alt="">
        </li>
        <li>
          <img src="../../../assets/m-3.jpg" alt="">
        </li>
        <li>
          <img src="../../../assets/m-4.jpg" alt="">
        </li>
      </ul>
    </div>
    <footer1></footer1>
  </div>
</template>
<script>
import HeaderCake from './Header_cake.vue'
import Footer from './Footer.vue'
export default {
  data(){
    return{

    }
  },
  components:{
    "headerCake" : HeaderCake,
    "footer1" : Footer    
  }
}
</script>
<style scoped>
  *{margin:0;padding:0;}
  li{list-style: none;}
  a{text-decoration: none;}
  /* 底部 */
  h2{
    width:1200px;
    font-size:18px;
    font-weight: 500;
    height:52px;
    line-height: 52px;
    border-bottom: 2px solid #CECAC7;
  }
  .myCart{
    width: 1200px;
    padding-top: 10px;
    padding-bottom: 50px;
  }
  .myCart>li{
    display: inline-block;
    width:300px;
    text-align: center;
  }
  .myCart>li>img{
    width:252px;
    height:252px;
  }
  /* 购物车内容 */
  .cart{
    height: 184px;
    width: 1198px;
    padding: 83px 0 115px;
    margin-top: 24px; 
    text-align: center;
  }
  .cart>img{
    width:204px;
    height:116px;
  }
  .cart>span{
    display: block;
    margin:10px;
    color:#D5BFA7;
    font-size:14px;
  }
  .cart>a{
    display:block;
    font-size:14px;
  }
</style>
