<template>
  <div class="footer">
    <div>
      <img src="../../../assets/footer-logo.png" alt="">
      <div class="footer_1">
        <router-link to="">联系我们</router-link>
        <span>|</span>
        <router-link to="">订购帮助</router-link>
        <span>|</span>
        <router-link to="">企业合作</router-link>
        <span>|</span>
        <router-link to="">生成经营资质</router-link>
        <span>|</span>
        <router-link to="">公告专区</router-link>
      </div>
      <div class="footer_2">
        <router-link to="">
          <img src="../../../assets/footericon-01.png" alt="">
        </router-link>
        <router-link to="">
          <img src="../../../assets/footericon-02.png" alt="">
        </router-link>
        <router-link to="">
          <img src="../../../assets/APP.png" alt="">
          <img class="footer-erweima" src="../../../assets/footer-erweima.png" alt="">
        </router-link>
      </div>
      <div class="footer_3">
        <span>订购专线：400 650 2121（服务时间 08:00–22:00），企业团购热线：021-37768396</span>
        <span>客服电话：021-23099721（全国），kefu@21cake.com（邮箱）</span>
        <span>杭州/广州：提前5小时预订；北京：提前6小时预订；上海：提前5.5-6小时预订；天津/苏州/无锡/深圳：提前8小时预订（部分偏远地区除外，当日22点以后订单，于次日8点开始审核）</span>
        <span>当日蛋糕配送截止下单时间：北京/上海：16:30；杭州/广州：14:00；天津：10:30；苏州/无锡/深圳：11:00</span>
        <span>网站注册公司名称: 北京廿一客食品有限公司 地址: 北京市北京经济技术开发区兴海二街5号院3号楼</span>
      </div>
      <div class="footer_4">
        <p>Copyright© 21Cake蛋糕官网商城 2007-2018, 版权所有 京ICP备14006254号-1</p>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  data(){
    return{}
  }
}
</script>
<style scoped>
*{margin:0;padding:0;}
a{text-decoration: none;}
li{list-style: none;}
  .footer{
    min-width:1200px;
    background:#333;
    padding: 50px 0 0 0;
    position: relative;
    top:0;
    left:0;
  }
  .footer>div{
    text-align: center;
  }
  .footer>div>img{
    width:96px;
  }
  /* 第二部分 1*/
  .footer>div>.footer_1{
    color:#fff;
    margin:25px 0;
  }
  .footer>div>div>a{
    color:#fff;
    margin:0 50px;
    font-size:12px;
  }
  /* 第二部分 2 */
  .footer_2{height:50px;position: relative;}
  .footer_2>a{
    display: inline-block;
    border-radius: 25px;
    height: 50px;
    width: 50px;
    background: #494949;
    margin: 0 25px;
    font-size: 16px;
    color: #fff;
    line-height: 50px;
    text-align: center;
    vertical-align: middle;
    position: relative;
  }
  .footer_2>a>img{
    width:30px;
    margin:10px;
  }
  .footer_2>a>.footer-erweima{
    width:70px;
    border:7px solid #fff;
    position: absolute;
    top:-21px;
    right:-194%;
    margin: 0;
    height:0;
    opacity: 0;
  }
  .footer_2>a:hover>.footer-erweima{
    opacity: 1;
    width:70px;
    height:70px;
    transition: all 0.5s;
  }
  /* footer_3 */
  .footer_3{margin-top:25px;}
  .footer_3>span{
    display: block;
    color:#9a9a9a;
    font-size:12px;
  }
  /* footer_4 */
  .footer_4{
    border-top:1px solid #9a9a9a;
    margin-top:15px;
  }
  .footer_4>p{
    font-size:12px;
    color:#9a9a9a;
    padding:15px 0;
  }
</style>
