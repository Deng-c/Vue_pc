<template>
  <div class="navigation">
    <router-link to="#" onclick="document.getElementById('divNode').scrollIntoView(true);return false;">
      <img src="../../../assets/xingpin.jpg" alt="新品">
    </router-link>
    <router-link to="" onclick="document.getElementById('divNode2').scrollIntoView(true);return false;">
      <img src="../../../assets/shenri.jpg" alt="生日">
    </router-link>
    <router-link to="" onclick="document.getElementById('divNode3').scrollIntoView(true);return false;">
      <img src="../../../assets/ertong.jpg" alt="儿童">
    </router-link>
    <router-link to="" onclick="document.getElementById('divNode4').scrollIntoView(true);return false;">
      <img src="../../../assets/juhui.jpg" alt="聚会">
    </router-link>
    <router-link to="" oncolick="document.getElementById('divNode5').scrollIntoView(true);return false;">
      <img src="../../../assets/huodong.png" alt="活动">
    </router-link>
  </div>
</template>
<script>
export default {
  data(){
    return{}
  }
}
</script>
<style scoped>
  .navigation{
    min-width:1124px;
    margin:26px 38px 0;
    text-align: center;
  }
  .navigation>a{
    display: inline-block;
    margin: 6px 12px;
    border-radius: 8px;
    background:#f5f5f5;
    box-shadow: 0 2px 6px #f5f5f5;
    overflow: hidden
  }
  .navigation>a>img{
    display:inline-block;
    width:200px;
    height: 100px;
    background:#fafafa url(../../../assets/list-img.png) center no-repeat ;
    background-size:auto 100%;
    opacity: 0.9;
  }
  .navigation>a>img:hover{
    transform: scale(1.02);
  }
</style>
