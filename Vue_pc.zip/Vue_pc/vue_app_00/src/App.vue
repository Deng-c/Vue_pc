<template>
  <div id="app">
    <!-- <div id="nav"> -->
      <!-- <router-link to="/">Home</router-link> | -->
      <!-- <router-link to="/about">About</router-link> -->
    <!-- </div> -->
    <router-view/>
  </div>
</template>

<style>
*{margin:0;padding:0;}
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  /* text-align: center; */
  color: #684029;
}
#nav {
  padding: 30px;
}

#nav a {
  font-weight: bold;
  color: #684029;
}

#nav a.router-link-exact-active {
  color: #684029;
}
li{list-style: none;}
a{text-decoration: none;color:#684029;}
</style>
