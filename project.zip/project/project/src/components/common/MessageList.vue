<template>
    <div>
   <div>
            <v-header></v-header>
   </div>
       
        <div class="divimg">        
            <div class="textdiv">
                <h3>熊猫蛋糕</h3>
                <el-breadcrumb separator-class="el-icon-arrow-right">
                <el-breadcrumb-item :to="{path:'/'}">首页</el-breadcrumb-item>
                <el-breadcrumb-item>美味蛋糕</el-breadcrumb-item>
                </el-breadcrumb>
                </div>
        </div>
        <div class="title_a">
            <h2>我们的蛋糕<i class="el-icon-burger"></i></h2>
        </div> 
        <div class="container">
         <div  class="bbb" v-for="(item,i) of list"  :key="i">  
             <el-row  :gutter="0">
                <el-col :xs="20" :sm="12" :md="12" :lg="6" :xl="6">
                    <div class="message_img_b">
                        <div class="message_img">
                             <img class="img_hover"  :src="'http://127.0.0.1:3000/img/'+item.pan_img" alt="">
                                <h4>￥{{item.price}} </h4>
                                <h3>{{item.title}}</h3>
                                <button>查看详情</button>
                              </div>
                           </div>
                        </el-col>  
                         
                  
            
                <el-col :xs="20" :sm="12" :md="12" :lg="6" :xl="6">
                    <div class="b">
                        <div class="message_img">
                         <img 
                   :src="'http://127.0.0.1:3000/img/'+item.pan_img" alt="">
                         <h4>￥123.00 </h4>
                       <h3>只对你有感觉-玫瑰奶油蛋糕</h3>
                         <button>查看详情</button>
                        </div>
                      
                    </div>
                    </el-col>  
                  
                    
              
                <el-col :xs="20" :sm="12" :md="12" :lg="6" :xl="6">
                    <div class="b">
                        <div class="message_img">
                            <img :src="'http://127.0.0.1:3000/img/'+item.pan_img" alt="">
                          <h4>￥123.00 </h4>
                       <h3>只对你有感觉-玫瑰奶油蛋糕</h3>
                         <button>查看详情</button>
                        </div>
                        
                        </div>
                        </el-col> 
                
                <el-col :xs="20" :sm="12" :md="12" :lg="6" :xl="6">
                    <div class="b">
                        <div class="message_img">
                        <img :src="'http://127.0.0.1:3000/img/'+item.pan_img" alt="">
                          <h4>￥123.00 </h4>
                          <h3>只对你有感觉-玫瑰奶油蛋糕</h3>
                          <button>查看详情</button>
                        </div>
                        
                        </div>
                        </el-col> 
                          </el-row> 
                      </div>
           
          
         </div>
    <div>
        <v-footer></v-footer>
    </div>
</div>
</template>
<script>
import footer from "./footer"
import Header from "./Header"
export default {
    data(){
        return{
           list:[]
        }
    },created(){
        this.loadMore();
    }, methods:{
        loadMore(){
            var url = "message"
            this.axios.get(url).then(result=>{
                this.list=result.data.data

            })
            }
    }
    ,components:{
        "v-header":Header,
         "v-footer":footer
    }
}
</script>
<style>

.divimg{
    margin-top: -40px;
    background: url("../../assets/banner-bg.jpg")no-repeat scroll center center;
    background-size: cover;
    width: 100%;
}
.textdiv{
    text-align: center!important;
    padding-bottom: 55px;
}
.textdiv h3{
    color: #fff;
   padding-top: 113px;
    font-size: 62px;
    font-family: "Playfair Display", serif;
}
.ul_a{
  list-style: none;
  color: #fff;
  display: inline-block;
  margin-right: 20px;

}
.el-breadcrumb{
    position: absolute;
    left: 45%;
      
}

.el-breadcrumb__inner {
  color: #fff!important;
} 
.title_a{
    padding-bottom: 50px;
}
.title_a h2{
    color: #3e606b;
    font-family: "Playfair Display", serif;
    font-weight: bold;
    font-size: 38px;
    position: relative;
    display: inline-block;
    margin-bottom: 15px
}

.container{
    width: 80%;
      margin: 0 auto;
    clear: both;
    padding: 0!important;
}

 .message_img{
         background-color :#ffffff;
         width: 80%;
         margin: 0 auto;
         clear: both;
         padding: 0!important;
         border: 1px solid #ffffff;
        border-radius: 5px;
        box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
        margin-bottom: 20px;  
 
 
 }
 
 .message_img img{
     width: 98%; 
     transition:all 300ms ease; 
 }
.message_img:hover img{
    transform: scale(1.03);
 
}

 
 .message_img h4{
   margin-top: -30px;
   margin-left:66px; 
   width: 80px;
    height: 80px;
    border-radius: 50%;
    color: #343434;
    font-size: 18px;
    font-family: "Playfair Display", serif;
    font-style: italic;
    background: #fff;
    display: inline-block;
  
    -webkit-transform: translateX(-50%);
    -ms-transform: translateX(-50%);
    transform: translateX(-50%);

    line-height: 68px;
    margin-bottom: 0px;
    z-index: 2;
 }
.message_img h3{
   font-size: 18px;
    color: #343434;
    font-family: "Playfair Display", serif;
    /* /* margin-bottom: 22px; */
     margin-top: 0px; 
}
.message_img button{
   background-color:  #94c9d9;
   border-radius: 5px;
   font-size:14px;
   color: #ffffff;
   line-height:36px;
   font-family: "Open Sans", sans-serif;
   font-size: 14px;
    font-weight: 600;
    border-radius: 3px;
    border: none;
    margin-bottom: 18px;
}
</style>
