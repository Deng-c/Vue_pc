<template>
  <div>
    <div class="row_1">
    <el-row :gutter="0">
      <el-col  :sm="6" :md="6" :lg="6" >
        <div>
          <span class="myspan">
            <i  class="icon iconfont">&#xe874;</i>
            0752-5201314
            </span>
          </div>
        </el-col>
      <el-col  :sm="8" :md="8" :lg="8" >
        <div class="div_header">
          <span class="myspan_1">
           <i class="icon iconfont">&#xe631;</i>
            wangjiyuan@520xmbz.com
          </span>
          </div>
        </el-col>
      <el-col  :sm="10" :md="5" :lg="10" >
        <div>
         <input class="myinput"  placeholder="搜索" type="search"  >
         <i class="el-icon-search"></i>
          <div>
            <el-breadcrumb separator="/">
            <el-breadcrumb-item :to="{ path: '/login' }">登陆</el-breadcrumb-item>
            <el-breadcrumb-item :to="{ path: '/login' }">注册</el-breadcrumb-item>
            <el-breadcrumb-item  :to="{ path: '/Cart' }" >购物车<i class="el-icon-shopping-cart-full"></i></el-breadcrumb-item>
          </el-breadcrumb>
          </div>
         </div>
        </el-col> 
     
      
   
    </el-row>
    <div class="myborder"></div>
    </div>
  <!-- ------------------------------------------------------------------------------------ -->
      <div>
          <el-row class="myheader hidden-sm-and-down">
            <el-col :sm="8" :md="8" :lg="9" >
              <div> 
              <ul  class="myul">
               <el-link href="http://127.0.0.1:8080/#/message"  type="info"> <li>首页</li></el-link>
                 
           <el-dropdown>
             <li> 
               关于熊猫 
               <i class="el-icon-arrow-down"></i> 
            </li>
          <el-dropdown-menu slot="dropdown">
              <el-dropdown-item >企业简历</el-dropdown-item>
              <el-dropdown-item divided>核心价值体系</el-dropdown-item>
              <el-dropdown-item divided>品质保证</el-dropdown-item>
              <el-dropdown-item divided>发展历程</el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
              
              <el-dropdown>
            <li> 美味蛋糕
               <i class="el-icon-arrow-down"></i> 
            </li>
            <el-dropdown-menu  class="dropdown" slot="dropdown">
                <el-dropdown-item>美味下午茶</el-dropdown-item>
                <el-dropdown-item divided>爆款蛋糕</el-dropdown-item>
                <el-dropdown-item divided>儿童蛋糕</el-dropdown-item>
                <el-dropdown-item divided>女神蛋糕</el-dropdown-item>
                <el-dropdown-item divided>鲜果蛋糕</el-dropdown-item>
                <el-dropdown-item divided>慕斯蛋糕</el-dropdown-item>
            </el-dropdown-menu>
              
              </el-dropdown>
             
              </ul>
              </div>
            </el-col>
            <el-col :sm="8" :md="8" :lg="6" >
               <div class="myimg"></div>
            </el-col>
            <el-col :sm="8" :md="8" :lg="9" >
               <div class="">
               <ul  class="myul">
                   <el-dropdown>
             <li> 
              新闻动态
               <i class="el-icon-arrow-down"></i> 
            </li>
          <el-dropdown-menu class="dropdown_a" slot="dropdown">
              <el-dropdown-item >公司活动</el-dropdown-item>
              <el-dropdown-item divided>熊猫公益</el-dropdown-item>
              <el-dropdown-item divided>媒体报道</el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
                
                <li>公司地址</li>
          <el-dropdown>
             <li> 
             联系我们
               <i class="el-icon-arrow-down"></i> 
            </li>
            <el-dropdown-menu class="dropdown_b" slot="dropdown">
              <el-dropdown-item >加入我们</el-dropdown-item>
              <el-dropdown-item divided>城市合伙人</el-dropdown-item>
            </el-dropdown-menu>
        </el-dropdown>
             
              </ul>
              </div>
            </el-col>
          </el-row>
       <div class="myborder_1"></div>
      </div>
         <div class="hidden-md-and-up">  
    <el-menu
      class="el-menu-vertical-demo"
      background-color="#fff"
      text-color="#000"
      active-text-color="#ffd04b"
      :default-active="this.$router.path"
      router>
      <el-submenu index="1">
        <template slot="title">
          <img class="myimg_2" src="../../assets/LOGO_h.png" alt="">
        </template>
          <el-menu-item-group>
         <el-menu-item index="1-1">首页</el-menu-item>
            </el-menu-item-group>
          <el-menu-item-group>
          <el-menu-item index="1-2">关于熊猫</el-menu-item>
            </el-menu-item-group>
          <el-menu-item-group>
          <el-menu-item index="1-3">美味蛋糕</el-menu-item>
            </el-menu-item-group>
          <el-menu-item-group>
          <el-menu-item index="1-4">新闻动态</el-menu-item>
            </el-menu-item-group>
          <el-menu-item-group>
          <el-menu-item index="1-5">公司地址</el-menu-item>
            </el-menu-item-group>
          <el-menu-item-group>
          <el-menu-item index="1-6">联系我们</el-menu-item>
        </el-menu-item-group>
       </el-submenu>
    </el-menu>
  </div>


</div>
</template>
<script>
export default {
    data(){
        return{
          list:[]
        }
    },meyhods:{
     
      
       
    }
}
</script>
<style>
  .el-dropdown-menu{
    position: relative;
    left: 170PX!important;
    width: 150px;
    font-size: 16px;
     font-weight:bold;
 }
 .dropdown{
   position: relative;
    left: 350PX!important; 
    /* top:165px!important; */
 }
.dropdown_a{
  position: relative;
    left: 1020PX!important; 
    /* top:165px!important; */
} 
.dropdown_b{
  position: relative;
    left: 1400PX!important; 
    /* top:165px!important; */
}
  .row_1{
   
    padding: 24px 0 ;
    background-color: #ffd04b;

  }
  .myspan{
    font-size: 16px;
    font-family: "Open Sans", sans-serif; 
    font-weight: 800;
  }
.myinput{
  border: 1px solid #000;
  border-radius: 25px;
  height: 34px;
  width: 245px;
  background: none;
  /* 去边框 */
  outline: none;
  text-indent:20px;
  
}
.myspan_1{
   font-size: 16px;
    font-family: "Open Sans", sans-serif; 
    font-weight: 800;
    /* float: left; */

}
.el-icon-search{
  position: relative;
  left: -5%;
}
.myborder{
  border-bottom:1px dashed #000; 
  position: relative;
  top:20px;
}

.myheader{

    height: 88px;
  background-color:#ffffff
}
.myul{
  list-style: none;
  display: flex;
  position: relative;
    top: 25px;
}
.myul li{
    font-weight:bold;
    margin-right: 100px; 
    white-space:nowrap;
    line-height: 26px;
    font-size: 18px;
    font-family: "Open Sans", sans-serif;
    color: #000;
}

.myimg:before{
  content: " ";
  display: block;
  width: 150px;
  height: 150px;
  background: url(../../assets/logo.png)no-repeat;
  background-size:100%  100%;
  margin: 0 auto;
  position: relative;
  top: 0px;
  z-index: 999;
}
.myborder_1{
   border-bottom:1px dashed #cfcfcf;
  position: relative;
  top:20px;
}
.myimg_2{
  width: 148px;
  height: 35.5px;
  position: absolute;
    left: 0;
    top: 10px;

}
.hidden-md-and-up{ 
  border-bottom:1px solid #cfcfcf
}
.el-submenu .el-menu-item{
  border-bottom: 1px solid #cfcfcf;
  font-size: 18px;
}
.el-breadcrumb{
  position: absolute;
    left: 77% !important;
}
</style>
