<template>
    <div>
        <div>
            <v-header></v-header>
        </div>
        <div class="iu_img">
           <div class="iu_img_masseag">
                <h3>爆款蛋糕</h3>
               <el-breadcrumb separator-class="el-icon-arrow-right">
                <el-breadcrumb-item :to="{path:'/'}">首页</el-breadcrumb-item>
                <el-breadcrumb-item>爆款蛋糕</el-breadcrumb-item>
                </el-breadcrumb>
           </div>       
        </div>
        <div class="container_a">
            <div class="product_d_price">
             <el-row >
                 <el-col :sm="24" :md="24" :lg="12" :xl="12">
                     <div class="img-flu">
                         <img :src="'http://127.0.0.1:3000/img/20190115133108148l.jpg'" alt="">
                     </div>
                     </el-col>
                 <el-col :sm="24" :md="24" :lg="12" :xl="12">
                     <div class="iu_title" v-if="list[0]">
                         <h4>{{list[0].title}}</h4>
                         <p>-{{list[0].p_type}}- </p>
                         <h5>价格：<span>{{list[0].price}}</span> </h5>
                        <button @click="cart_sum">加入购物车+</button>
                     </div>
                     </el-col>
             </el-row>
            </div>
            <div>
                <div class="iu_massage">
                    <p>蛋糕详情</p>
                </div>
                <div class="img_border">
                       <img src="../../assets/1546748421973347.jpg" alt="">
                </div>
            </div>
        </div>
        <div>
            <v-footer></v-footer>
        </div>
    </div>
</template>
<script>
import Header from "./Header"
import footer from "./footer"
export default {
    data(){
        return{
            list:[],
        }
    },created(){
        this.loadMore()
    }
    ,
    methods:{
       loadMore(){
            var url = "message"
            this.axios.get(url).then(result=>{
                this.list=result.data.data
                console.log(this.list)
            })
            },
        cart_sum(){
        var  img=this.list[0].pan_img
        var  til=this.list[0].title
        var  pri=this.list[0].price
        var  cou= 1
        var  id=1
        var url="cart_sum"
        var obj={img_url:img,title:til,price:pri,count:cou,p_id:id}
        this.axios.get(url,{params:obj}).then(result=>{
            if(result.data.code==1){
                  this.$message.success("加入成功")
            }
        })
        }     

    },
    components:{
        "v-header":Header,
        "v-footer":footer

        }
}
</script>
<style>
.img_border{
    border: 1px solid #e2e2e2;
    box-sizing: border-box;
    height: auto;
    width: 85%;
    margin-left: 176px;
    margin-bottom: 50px;
}
.iu_massage{
    margin-left: 176px;
    width: 114px;
    border: 1px solid #e2e2e2;
    border-bottom-color:#fff ;
    border-top: 4px solid #f195b2;
    margin-top: 0px;
      z-index: 100;
    position: relative;
    top:1px;
}
.product_d_price{
    margin-bottom:80px; 
}
.iu_img{
    margin-top: -40px;
    background: url("../../assets/banner-bg.jpg")no-repeat scroll center center;
    background-size: cover;
    width: 100%;
}
.iu_img_masseag{
    text-align: center!important;
    padding-bottom: 55px;
}
.iu_img_masseag h3{
      color: #fff;
   padding-top: 113px;
    font-size: 62px;
    font-family: "Playfair Display", serif;
}
.container_a{
    padding-top: 50px;
    width: 100%;
    padding-right: 15px;
    padding-left: 15px;
    margin-right: auto;
    margin-left: auto;
}
.img-flu{
  padding-right:45px; 
     
}
.img-flu img{
    max-width: 100%;
  
    height: auto;
}
.iu_title h4{
    font-size: 36px;
    color: #3e606b;
    font-family: "Playfair Display", serif;
    font-weight: bold;
    border-bottom: 1px solid #eaeaea;
    margin-bottom: 0px;
    padding-bottom: 20px;
}
.iu_title p{
    font-size: 16px;
    line-height: 26px;
    color: #797979;
    font-family: "Open Sans", sans-serif;
    border-bottom: 1px solid #eaeaea;
    margin-bottom: 0px;
    padding: 30px 0px;
}
.iu_title h5{
    font-size: 18px;
    color: #242424;
    font-family: "Open Sans", sans-serif;
    font-weight: 600;
    padding: 25px 0px;
    margin: 0px;

}
.iu_title  button{
    background-color:#684029;
    width: 167px;
    height: 30px; 
    border: none;
    color: #fff;

}
.iu_title  button:hover{
    color: yellow;
}

</style>
