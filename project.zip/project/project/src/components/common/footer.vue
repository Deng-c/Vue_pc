<template>
    <div class="myfooter">
          <div>
            <el-row>
               <el-col :sm="8" :md="8" :lg="8">
                   <div class="footerleft">
                    <h3 style="margin-left: 44px">快速链接</h3>
                        <ul class="Ul_a">
                            <li>关于熊猫</li>
                            <li>美味蛋糕</li>
                            <li>新闻动态</li>
                            <li>公司地址</li>
                            <li>联系我们</li>
                        </ul>
                   </div>
                   </el-col>
               <el-col :sm="8" :md="8" :lg="8">
                   <div class="footerleft">
                       <h3>下单时间与服务时间：</h3>
                        <ul class="Ul_a">
                            <li>营业时间：24小时在线下单</li>
                            <li>客服时间：09：00—24：00</li>
                        </ul>
                   </div>
                   </el-col>
               <el-col :sm="8" :md="8" :lg="8">
                   <div class="footerleft">
                       <h3>联系信息</h3>
                        <p>0752-5201314</p>
                        <p>惠州市惠城区云山西路2号帝景国际商务中心2座22层01号</p>
                        <p>wangjiyuan@520xmbz.com</p>
                   </div>
                   </el-col>
           </el-row> 
          </div>
 <!-- ---------------------------------------------- -->
            
            <div class="footerleft_a">
                <el-row>
                    <el-col :sm="12" :md="12" :lg="12">
                        <div class="hover_a">© 熊猫不走蛋糕版权所有 粤ICP备18030870号-1 </div>
                        </el-col>
                    <el-col :sm="12" :md="12" :lg="12">
                        <div class="hover_b">  
                         <el-link href="http://www.baidu.com"  type="info"><p>技术支持：万鸿信息技术</p></el-link>
                        </div>
                        </el-col>
                </el-row>
            </div>  
    </div>
</template>
<script>
export default {
    data(){
        return{}
    }
}
</script>
<style>
.myfooter{
    background: #303339;
    overflow: hidden;
   
}
.Ul_a{
 list-style: none;
}
.Ul_a li{
     padding-top:15px
}
.Ul_a li:hover{
    color: #ffd04b
}
.footerleft{
   font-size: 14px;
    color: #fff
}
.footerleft h3:hover{
     color: #ffd04b 
}
.footerleft  p:hover{
     color: #ffd04b 
}
.footerleft_a{
    padding: 20px 0;
    font-size: 14px;
    color: #fff; 
    border-top: 1px solid slategray
}

      
.hover_a:hover{
    color: #ffd04b
}

</style>























