<template>
    <div>
       <div>
           <v-header></v-header>
       </div>
        
        <div class="divImg_login">
           <el-row>
               <el-col :sm="1" :md="8" :lg="8">
                    <div>
                        
                    </div>
               </el-col>
               <el-col :sm="22" :md="8" :lg="8">
                    <div class="loginlist">
                       <el-tabs v-model="activeName" >
                        <el-tab-pane 
                        label="用户登录" 
                        name="second">
                        <div class="input_login">
                             <el-input
                            placeholder="用户名"
                            v-model="input"
                            prefix-icon="el-icon-user-solid"
                            clearable>                           
                            </el-input>                            
                             <div class="password">
                             <el-input
                            placeholder="密码"
                            v-model="password"
                            prefix-icon="el-icon-unlock"
                            show-password >                      
                            </el-input>
                             </div>
                          <button @click="login" :plain="true"> 登录 </button>
                        <el-divider>其他登录方式</el-divider>   
                        </div>                                                           
                        </el-tab-pane>
                        
                        <el-tab-pane 
                        label="用户注册" 
                        ame="third">
                        <div class="input_login">
                             <div>
                              <el-input
                            placeholder="用户名"
                            v-model="cname"
                            prefix-icon="el-icon-user-solid"
                            clearable>                           
                            </el-input>  
                              </div>
                         
                               <div class="input_zc">
                                     <el-input
                            placeholder="手机"
                            v-model="cphone"
                            prefix-icon="el-icon-message"
                            clearable>                           
                            </el-input>   
                               </div>
                              <div class="input_zc">
                                   <el-input
                            placeholder="密码"
                            v-model="password_a"
                            prefix-icon="el-icon-unlock"
                            show-password >
                            </el-input>
                              </div>
                           <div class="input_zc">
                                <el-input
                            placeholder="请重复密码"
                            v-model="password_b"
                            prefix-icon="el-icon-unlock"
                            show-password >
                            </el-input>
                           </div>
                              
                               <button 
                               @click="insert"
                               :plain="true"> 
                                   立即注册
                                   </button>

                        </div>
                        </el-tab-pane>
                    </el-tabs>    
                            

                    </div>
               </el-col>
               <el-col :sm="1" :md="8" :lg="8">
                    <div >
                        
                    </div>
               </el-col>
           </el-row>
        </div> 
    <div>
        <v-footer></v-footer>
    </div>
    </div>
</template>
<script>
import Header from "./Header"
import footer from "./footer"
export default {
    data(){
        return{
                fullscreenLoading: false,
                activeName: 'second',
                input:"paopao",
                password:"123456",
                cname:"",
                cphone:"",
                password_a:"",
                password_b:""
    }
    },
    methods:{
        login(){
        var u=this.input ;
        var p=this.password;
    var reg=  /^[a-z0-9_]{3,12}$/i;
        if(!reg.test(u)){
        this.$message.error('用户名格式不正确');
        return
        }
       if(!reg.test(p)){
       this.$message.error("密码格式不正确");
         return;
         }
// ajax
    var url = "login"
    var obj ={pname:u,ppwd:p}
    this.axios.get(url,{params:obj}).then(
        result=>{
           console.log(result)
           if(result.data.code==1){
            const loading = this.$loading({
             lock: true,
             text: 'Loading',
             spinner: 'el-icon-loading',
            background: 'rgba(0, 0, 0, 0.7)'
            });
            setTimeout(() => {
            loading.close();
          }, 2000);
            this.$message("登录成功")
          this.$router.push("/messagelist")
           }else{
                this.$message("登录失败，账号或密码有误")
           }
        }
    )
     },
      insert(){
               var cn=this.cname
               var cp=this.cphone
               var pa=this.password_a
               var pb=this.password_b
               var reg= /^[a-z0-9_]{3,12}$/i;
               var mPattern = /^1[34578]\d{9}$/;
        if(!reg.test(cn)){
            this.$message.error('用户名格式不正确');
        return
       }
        if(!reg.test(pa)){
             this.$message.error("密码格式不正确");
        return
       }else if(pb!=pa){
            this.$message.error("密码不一致")
        return
      }
      if(!mPattern.test(cp)){
             this.$message.error("电话格式不正确");
        return
       }
    //    ajax
     var url = "reg"
     var obj ={pname:cn,ppwd:pa,phone:cp}
    this.axios.get(url,{params:obj}).then(result=>{
        // console.log(result) 
        if(result.data.code==200){
          const loading = this.$loading({
             lock: true,
             text: 'Loading',
             spinner: 'el-icon-loading',
            background: 'rgba(0, 0, 0, 0.7)'
            });
            setTimeout(() => {
            loading.close();
          }, 2000);
            this.$message("注册成功")
              sessionStorage.setItem('uname',this.cname)
              this.$router.push("/login")
              
        }else if(result.data.code==201){
           this.$message.error("用户名已存在")
        return
      }
     })    
        
    } 
},
    components:{
        "v-header":Header,
        "v-footer":footer

        }
}
</script>

<style>
.divImg_login{
margin-top:20px;
background: url("../../assets/passport-banner.jpg")
no-repeat scroll center center;
background-size: cover;
width: 100%;
height: 600px;
}
.loginlist{
height: 390px;
margin-top:70px;
background-color: #ffffff; 
border: 1px solid #cfcfcf;
border-radius: 5px;
box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}
.loginlist button{
width: 180px;
height: 35px;
border-radius: 25px;
background-color: #fe4320;
border: 1px solid#fe4320;
margin-top: 30px;
box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}
.password{
margin-top: 30px;
}
 .el-tabs__active-bar{ 
width: 0px !important;
 } 
.el-tabs__nav{
float:none!important;
}
.input_login{
width: 60%;
margin-left: 100px; 
}
.el-input__inner{
border: 0 !important;
border-bottom: 1px solid #e5e5e5 !important;
background-color: #ffffff !important;
}
.el-input__prefix, .el-input__suffix{
color: #4c453c!important;
}
.input_zc{
margin-top: 30px;
}
</style>
