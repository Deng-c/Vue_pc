<template>
    <div> 
<div>
     <v-header></v-header>
</div>
<!-- -------------------购物车----------------------- -->
   
    
    <div class="Cart_center " >
      
                     <div class="Cart_a">
            
                            <div class="Cart_b" v-for="(item,i) of list"  :key="i">
                               <div class="cart_img">
                                  
                            <input type="checkbox" v-model="item.cb" @change="change" />
                                 
                                <img 
                                :src="'http://127.0.0.1:3000/img/'+item.img_url"
                                 alt="">
                               </div>
                               <div class="cart_title">
                                   <span>{{item.title}}</span>
                                   <h4>{{item.p_type}}</h4>
                                   <p>￥ {{item.price}}</p>
                               </div>
                            <div class="cart_title_right">
                                <p>小计：￥{{item.price*item.count}}</p>
                                <!-- <span>删除</span> -->
                                <el-input-number 
                               @change="change"
                                v-model="item.count" 
                               :min="1" 
                               :max="99"
                                 label="描述文字"></el-input-number>
                            </div>
                            </div>                
                             
                      </div>
         
     
    </div>
<!-- ------------------购物车底部---------------------------- -->
    <div class="Cart_footer">
        <el-row>
            <el-col :sm="8" :md="8" :lg="12">
            全选
             <input type="checkbox"  @change="selectAll">
             <span @click=" delitem">删除</span>
                <el-divider direction="vertical"></el-divider>
                <span>共{{list.length}}件商品，已选择{{n}}件</span>
            </el-col>
            <el-col :sm="8" :md="8" :lg="12">
                    <div>
                        <span>应付（不含运费）：￥{{price}}</span>
                     <el-button type="success" size="medium" plain>结算</el-button>
                    </div>
            </el-col>
        </el-row>
    </div>
    <div class="myfoot">
           <!-- <v-footer></v-footer> -->
    </div>
     
    
</div>
</template>
<script>
import Header from "./Header"
import footer from "./footer"
export default {
    
    data(){

   
      
      return{
            price:0,
            n:0,
            radio:'1',
            list:[],
            
        }
    },created(){
        this.loadMore();
    },
methods:{

delitem(){
            // var id=e.target.dataset.id;
            var str = "";
        for(var item of this.list){
            if(item.cb){
                str+=item.uid+","
            // console.log(str)
            }         
        }
    // 截取逗号之前的内容
    str = str.substring(0,str.length-1)
 
    // 判断用户没有选中商品
    if(str.length==0){
    this.$alert("请选中商品","提示：")
        return;
        }
    this.$confirm("是否删除指定数据","提示：",{
                   cancelButtonText: '取消',
                 confirmButtonText: '确定',
    }).then(action=>{   
        
    // ajax
    var url="delitem";
    var obj = {uid:str} 
    this.axios.get(url,{params:obj}).then(result=>{
        // 获取没有删除的商品
        this.loadMore();
    });
     }).catch(err=>{
         return
     })   // 重新加载数据


     },
// **********************
change(){
    this.n=0;
    for(var a=0;a<this.list.length;a++){      
       if(this.list[a].cb){
        this.n+=this.list[a].count
        this.price= this.list[a].price*this.n 
            }
        }
     },
//************************
        // 全选按钮
selectAll(e){
     //全选按钮状态
     var cb =  e.target.checked;
   
   
    //依据状态修改列表cb
     for(var item of this.list){
        item.cb = cb;
     }
     this.change()
        },
        //获取数据
loadMore(){
            
            var url="cart"      
            this.axios.get(url).then(result=>{
            // this.list=result.data.data
            // console.log(this.list)
            var rows= result.data.data;
            // 添加cb属性
            for(var item of rows){
                item.cb=false;
             
                // this.$store.commit("increment");

            }
            // 保存
            this.list=rows
         
        })
      }


    },
components:{
        "v-header":Header,
        "v-footer":footer

    }
}
</script>
<style>

.Cart_footer{
    width: 100%;
    position:fixed;
    bottom: 0px;
    background-color: azure;
    border-top: 1px solid #cfcfcf;
    height: 100px;
   z-index: 999;
   
}
.Cart_center{
    width: auto;
    margin: 0 auto;
    clear: both;
    /* border: 1px solid; */
    padding: 0!important;
 
    
}
.Cart_a{
    width: 70%;
    margin: 0 auto;
 
}
.Cart_b{
    width: 100%;
    height: 150px;
    border: 1px solid #e5e5e5;
   margin-top:30px; 
   display:flex;
   float: left !important;
}

.cart_img{
    height: 110px;
    width: 120px;
  display: flex;
  align-items: center;
  position: relative;
    top: 30px;
}
.cart_img img{
    width: 110px;
    height: 100%;
    
}
.cart_title{
    position: relative;
    left: 36px;
    top: 25px;
    text-align: left;
    margin-left: 20px;
    width: 57%;
}
.cart_title_right{
    position: relative;
    width: 195px;
    height: 100%;
 top: 20px;
}
.cart_title_right p{
    
    font-size: 14px;
    color: #ff4001;
    text-align: right;
    padding-bottom: 30px;
}
.cart_title h4{
   line-height: 20px;
    color: #949494;
    font-size: 10px;
    margin: 0;
}
.cart_title span{
   font-size: 14px;
    line-height: 22px;
}
.cart_title p{
      color: #949494;
    font-size: 10px;
    margin-top: 50px;
}
.el-button--success.is-plain{
    margin-left: 20px;
}
.el-checkbox__input{
    margin-left: 10px;
}
</style>
