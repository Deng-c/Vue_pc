<template>
<div>
    <div>
            <v-header></v-header>
    </div>
     <!-- ^^^轮播图^^^ -->
    <div class="carousel" >
        <el-row>
            <el-col  :sm="24" :md="24" :lg="24">
        <el-carousel >
        <el-carousel-item  >
            <img width="100%" src="../../assets/20190109144757142a.jpg" alt="">
        </el-carousel-item>
        <el-carousel-item  >
            <img width="100%" src="../../assets/20190112115420338m.jpg" alt="">
        </el-carousel-item>
        <el-carousel-item >
            <img width="100%" src="../../assets/20190112115340319t.jpg" alt="">
        </el-carousel-item>
        </el-carousel>
     </el-col>
    </el-row>
  </div>
 <!-- ------------------------------------ -->
    <div class="container">
        <div class="">
            <el-row>
                <el-col :sm="24" :md="24" :lg="12">
                    <div class="main_title"> 
                        <div class="">
                            <h2>关于熊猫</h2>
                            <p>公司自成立之日起，始终奉行“用户至上，
                                产品为王”的理念，
                                推出了“熊猫人免费上门跳舞”、
                                “熊猫人拉小提琴”、
                                “熊猫人为你策划生日”
                                等差异化加体验感的服务模式，
                                以贴......</p>
                            </div> 
                        <div class="main_title_a">
                            <p>熊猫不走蛋糕诞生于2017年12月5日，
                                是一家以经营生日蛋糕为主，
                                融汇世界各地蛋糕特色于一体的蛋糕电商公司。
                                公司自成立之日起，
                                始终奉行“用户至上，产品为王”的理......</p>
                                <span>了解我们的更多信息</span> 
                            </div> 

                    </div>
                </el-col>
                <el-col :sm="24" :md="24" :lg="12">
                    <div class="title_img">
                           <img src="../../assets/20190109160530895k.jpg" alt=""> 
                    </div>
                </el-col>
            </el-row>
        </div>
        <!-- 分割线 -->
         <el-divider></el-divider>
        </div>   
   <!-- -------------三楼--------------------- -->
       <div class="cake_feature_inner">
           <div class="main_title">
               <h2>我们的特色蛋糕</h2>
           </div>
           <div>
               <div>
                   <el-carousel :interval="4000" type="card" height="200px">
              <el-carousel-item>
                    <div class="message_img_a">
                         <img 
                   src="../../assets/20190114112210710w.jpg" alt="">
                         <h4>￥123.00 </h4>
                       <h3>只对你有感觉-玫瑰奶油蛋糕</h3>
                         <button>查看详情</button>
                        </div>
             </el-carousel-item>
                <el-carousel-item>
                 <div class="message_img_a">
                         <img 
                   src="../../assets/20190114112210710w.jpg" alt="">
                         <h4>￥123.00 </h4>
                       <h3>只对你有感觉-玫瑰奶油蛋糕</h3>
                         <button>查看详情</button>
                        </div>
             </el-carousel-item>
                <el-carousel-item>
                <div class="message_img_a">
                         <img 
                   src="../../assets/20190114112210710w.jpg" alt="">
                         <h4>￥123.00 </h4>
                       <h3>只对你有感觉-玫瑰奶油蛋糕</h3>
                         <button>查看详情</button>
                        </div>
             </el-carousel-item>
                <el-carousel-item>
                  <div class="message_img_a">
                         <img 
                   src="../../assets/20190114112210710w.jpg" alt="">
                         <h4>￥123.00 </h4>
                       <h3>只对你有感觉-玫瑰奶油蛋糕</h3>
                         <button>查看详情</button>
                        </div>
             </el-carousel-item>
                     </el-carousel>
               </div>
           </div>
       </div>
    <!-- -------------四楼-------------- -->
        <div>
                <div class="bg_img">
                  
                     <div class="bg_div">                       
                         <el-carousel direction="horizontal" 
                         indicator-position="none"
                         :autoplay="false" 
                         height="150px">
                         <el-carousel-item >
                             <el-row >
                                 <el-col :sm="24" :md="24" :lg="12">
                                      <div class="d-flex">
                                <img src="../../assets/20190114112210710w.jpg" alt="">    
                                    </div>
                                 </el-col>
                                <el-col :sm="24" :md="24" :lg="12">
                                            <div class="text_title">
                                               <h4>感恩款-感谢有你蛋糕</h4>     
                                                <p>-水果奶油系列-</p>
                                            </div>
                                </el-col>
                             </el-row>                        
                         </el-carousel-item>
                          <el-carousel-item >
                             <el-row >
                                 <el-col :sm="24" :md="24" :lg="12">
                                      <div class="d-flex">
                                <img src="../../assets/20190114112210710w.jpg" alt="">    
                                    </div>
                                 </el-col>
                                <el-col :sm="24" :md="24" :lg="12">
                                            <div class="text_title">
                                               <h4>感恩款-感谢有你蛋糕</h4>     
                                                <p>-水果奶油系列-</p>
                                            </div>
                                </el-col>
                             </el-row>                         
                         </el-carousel-item>
                          <el-carousel-item >
                             <el-row >
                                 <el-col :sm="24" :md="24" :lg="12">
                                      <div class="d-flex">
                                <img src="../../assets/20190114112210710w.jpg" alt="">    
                                    </div>
                                 </el-col>
                                <el-col :sm="24" :md="24" :lg="12">
                                            <div class="text_title">
                                               <h4>感恩款-感谢有你蛋糕</h4>     
                                                <p>-水果奶油系列-</p>
                                                <span>查看详情</span>
                                            </div>
                                </el-col>
                             </el-row>
                         </el-carousel-item>
                         </el-carousel> 
                     </div>
                 </div>
 <!-- ----------------菜单------------------------ -->
                <div class="service_area">
                        <div class="container">
                                <div class="single_w_title">
                                    <h2>主要服务</h2>
                                
                                </div>
                            <div>
                                <el-row>
                                    <el-col :sm="24" :md="8" :lg="8">
                                        <div class="service_item">
                                          <i class="iconfont">&#xe608;</i>
                                          <h4>庆祝蛋糕</h4>
                                        </div>
                                    </el-col>
                                    <el-col :sm="24" :md="8" :lg="8">
                                        <div class="service_item">
                                            <i class="iconfont">&#xe607;</i>
                                             <h4>生日蛋糕</h4>
                                        </div>
                                        </el-col>
                                    <el-col :sm="24" :md="8" :lg="8">
                                        <div class="service_item">
                                            <i class="iconfont">&#xe627;</i>
                                            <h4>宴会蛋糕</h4>
                                        </div>
                                        </el-col>
                                </el-row>
                            </div>
                        </div>
                </div>
             <section class="discover_menu_area">
                 <div class="discover_menu_inner">
                    <div class="container">
                          <div class="title_dis">
                               <h2>菜单</h2> 
                          </div>
                          <el-row>
                              <el-col :sm="24" :md="12" :lg="12">
                                     <div class="discover_item_inner">
                                        <div  class="discover_item">
                                            <h4>只对你有感觉-玫瑰奶油蛋糕</h4>
                                            <p>
                                                <span>-玫瑰奶油-</span>
                                                <span>$166.00</span>
                                            </p>
                                        </div>
                                        <div  class="discover_item">
                                            <h4>送长辈</h4>
                                            <p>
                                                <span>送长辈</span>
                                                <span>$198.00</span>
                                            </p>
                                        </div>
                                        <div  class="discover_item">
                                            <h4>感恩款-感谢有你蛋糕</h4>
                                            <p>
                                                <span>-水果奶油系列-</span>
                                                <span>$210.00</span>
                                            </p>
                                        </div>
                                        <div  class="discover_item">
                                            <h4>海盐芝士流心蛋糕</h4>
                                            <p>
                                                <span>-抖音网红蛋糕-</span>
                                                <span>$278.00</span>
                                            </p>
                                        </div>
                                     </div>
                              </el-col>
                                <el-col :sm="24" :md="12" :lg="12">
                                    <div>
                                          <div class="discover_item_inner">
                                        <div  class="discover_item">
                                            <h4>只对你有感觉-玫瑰奶油蛋糕</h4>
                                            <p>
                                                <span>-玫瑰奶油-</span>
                                                <span>$166.00</span>
                                            </p>
                                        </div>
                                        <div  class="discover_item">
                                            <h4>送长辈</h4>
                                            <p>
                                                <span>送长辈</span>
                                                <span>$198.00</span>
                                            </p>
                                        </div>
                                        <div  class="discover_item">
                                            <h4>感恩款-感谢有你蛋糕</h4>
                                            <p>
                                                <span>-水果奶油系列-</span>
                                                <span>$210.00</span>
                                            </p>
                                        </div>
                                        <div  class="discover_item">
                                            <h4>海盐芝士流心蛋糕</h4>
                                            <p>
                                                <span>-抖音网红蛋糕-</span>
                                                <span>$278.00</span>
                                            </p>
                                        </div>
                                     </div>
                                   </div>
                              </el-col>
                          </el-row>
                          
                        
                    </div>
                 </div>
            </section>
        </div>
  <div>
      <v-footer></v-footer>
  </div>
</div>
</template>
<script>
import Header from "./Header"
import footer from "./footer"
export default {
    data(){
        return{}
    },
    components:{
        "v-header":Header,
        "v-footer":footer

        }
}
</script>
<style> 
.discover_item_inner .discover_item p span{
    color: #e3764b;
    font-size: 18px;
    font-family: "Playfair Display", serif;
    font-weight: bold;
}
.discover_item>p>span:last-child{
    float: right !important;
    width: 20%;
}
.iconfont{
    font-size: 70px !important;
}
 .service_item {
    font-size: 24px;
    font-family: "Playfair Display", serif;
    font-weight: bold;
    margin: 20px 0px 15px 0px;
}
.service_item{
    color: #fff;
    text-align: center;
}
.service_area{
    background: rgb(255,217,0);
    background-size: cover;
    padding: 100px 0px 155px 0px;
}
.single_w_title{
    text-align: center;
    margin-bottom: 40px;
}
.single_w_title h2{
    font-size: 36px;
    color: #fff;
    font-family: "Playfair Display", serif;
    font-weight: bold;
    position: relative;
    padding-bottom: 0px;
    margin-bottom: -30px;
}
.discover_item>p>span:nth-child(1){
    color: #797979 !important;
    float: left !important;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    width: 80%;
}
.discover_item p{
    font-size: 16px;
    font-family: "Open Sans", sans-serif;
    color: #797979;
    margin-bottom: 80px;
    margin-top:0px;
}
.discover_item h4{
    font-size: 20px;
    font-family: "Playfair Display", serif;
    font-weight: bold;
    color: #242424;
    margin-bottom: 10px;
    margin-top:0px 
}
.title_dis h2{
    color: #3e606b;
    font-family: "Playfair Display", serif;
    font-weight: bold;
    font-size: 38px;
    position: relative;
    display: inline-block;
    margin-bottom: 15px;
}

.discover_menu_inner{
    max-width: 1345px;
    margin: auto;
    background: #fff;
    margin-top: -60px;
    padding-top: 100px;
    padding-bottom: 115px;
        margin-right: 135px;
}
.discover_menu_area{
    position: relative;
}
.discover_menu_area:before{
    background: url("../../assets/menu-left.png") no-repeat scroll center center;
    content: "";
    width: 260px;
    height: 480px;
    position: absolute;
    left: 0px;
    top: 13%;

}
.discover_menu_area:after{
    background: url("../../assets/menu-right.png") no-repeat scroll center center;
    content: "";
    width: 260px;
    height: 640px;
    position: absolute;
    right: 0px;
    bottom: 0px;
    top:0;
}
.d-flex {
    position: relative;
    padding-right: 150px;
}
.d-flex:before{
    content: "";
    height: 235px;
    width: 1px;
    background: #ffffff;
    position: absolute;
    right: 50px;
    top: 10%;
    
    
}
.text_title h4{
    font-size: 48px;
    font-family: "Playfair Display", serif;
    font-weight: bold;
    color: #fff;
    margin-bottom: 20px;
}
.text_title p{
    font-size: 20px;
    color: #fff;
    font-family: "Lora", serif;
    font-style: italic;
    line-height: 30px;
    padding-right: 80px;
    margin-bottom: 32px;
}
.text_title span{
    background: #fff;
    color: #242424;
    line-height: 45px;
    display: inline-block;
    padding: 0px 35px;
    border-radius: 22px;
    font-family: "Open Sans", sans-serif;
    position: relative;
    overflow: hidden;
    font-size: 15px;
    font-weight: 600;
}
.el-carousel__indicators--vertical{
    top: 25% !important;
}
.bg_div{
    position: relative;
    top: 70px;
}
.el-carousel__container{
    height: 500px!important;
}

.carousel{
   
    height: 400px;
}
  
 .container {
     width: 100%;
    padding-right: 15px;
    padding-left: 15px;
    margin-right: auto;
    margin-left: auto;
 }

.main_title h2{
    color: #3e606b;
    font-family: "Playfair Display", serif;
    font-weight: bold;
    font-size: 38px;
    position: relative;
    display: inline-block;
    margin-bottom: 15px;
}
.main_title p{
    font-size: 20px;
    line-height: 30px;
    font-family: "Lora", serif;
    color: #242424;
    margin-bottom: 0px;
}
 .main_title_a p{
    line-height: 26px;
    color: #797979;
    font-size: 16px;
    font-family: "Open Sans", sans-serif;
    margin-bottom: 35px;
}
 .main_title_a span{
    background: #ffd900;
    color: #fff;
    line-height: 45px;
    border-radius: 22px;
    display: inline-block;
    padding: 0px 32px;
    font-size: 16px;
    font-family: "Open Sans", sans-serif;
    position: relative;
    overflow: hidden;
    font-weight: 600;
}
.title_img{
    padding-left: 40px;
}
.title_img img{
    max-width: 100%;
    height: auto;
}
.bg_img{
    background: url("../../assets/special-recipe.jpg") no-repeat fixed center center;
    background-size: cover;
    /* padding-top: 140px; */
    padding-bottom: 100px;

    position: relative;
    width: 100%;
}
.cake_feature_inner{
    padding: 10px 0px 100px 0px;
}

.message_img_a{
         background-color :#ffffff;
         width: 40%;
         margin: 0 auto;
         clear: both;
         padding: 0!important;
         border: 1px solid #ffffff;
        border-radius: 5px;
        box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
        margin-bottom: 20px;  
 
}
.message_img_a button{
   background-color:  #94c9d9;
   border-radius: 5px;
   font-size:14px;
   color: #ffffff;
   line-height:36px;
   font-family: "Open Sans", sans-serif;
   font-size: 14px;
    font-weight: 600;
    border-radius: 3px;
    border: none;
    margin-bottom: 18px;
}
.message_img_a img{
     width: 98%; 
     transition:all 300ms ease; 
 }
.message_img_a:hover img{
    transform: scale(1.03);
 
}
</style>


