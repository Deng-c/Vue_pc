import Vue from 'vue'
import Router from 'vue-router'
import Home from './views/Home.vue'
import Header from './components/common/Header.vue'
import footer from './components/common/footer.vue'
import Message from './components/common/Message.vue'
import MessageList from './components/common/MessageList.vue'
import Cart from './components/common/Cart.vue'
import Login from './components/common/Login.vue'
import IUismylove from './components/common/IUismylove.vue'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path:'/IUismylove',component:IUismylove
    },
    {
      path:'/Login',component:Login
    },
    {
      path:'/Cart',component:Cart
    },
    {
      path:'/MessageList',component:MessageList
    },
    {
      path:'/Message',component:Message
    },
    {
      path:'/footer',component:footer
    },
    {
      path:'/Header',component:Header
    },
    {

      path: '/',
      name: 'home',
      component: Home
    },
    {
      path: '/about',
      name: 'about',
      // route level code-splitting
      // this generates a separate chunk (about.[hash].js) for this route
      // which is lazy-loaded when the route is visited.
      component: () => import(/* webpackChunkName: "about" */ './views/About.vue')
    }
  ]
})
