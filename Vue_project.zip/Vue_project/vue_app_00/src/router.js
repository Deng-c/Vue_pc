import Vue from 'vue'
import Router from 'vue-router'
import Home from './views/Home.vue'
import HelloContainer from "./components/HelloWorld.vue"
// 
import Home1 from "./components/msj/Home1.vue"
// 
import MesageList from "./components/msj/common/MesageList.vue"
// import Login from "./components/msj/common/Login.vue"
// 详情页全局引入
import Particular1 from './components/msj/common/Particular1.vue'
//
import LoginMe from "./components/msj/common/LoginMe.vue"
//
import Logincg from './components/msj/common/Logincg.vue';
Vue.use(Router)
//2. 为Exam01.vue 配置路径

export default new Router({
  routes: [
    // {
    //   path:"/Message",
    //   component:Message
    // },
    // {
    //   path:"/login",
    //   component:Login
    // },
    {
      path:'/Logincg',
      component:Logincg
    },
    {
      path:'/LoginMe',
      component:LoginMe
    },
    {
      path:'/Particular1',
      component:Particular1
    },
    {
      path:"/MesageList",
      component:MesageList
    },
    {
      path:"/Home1",
      component:Home1
    },
    {
      path: '/',
      name: 'home',
      component: Home
    },
    {
      path: '/about',
      name: 'about',
      // route level code-splitting
      // this generates a separate chunk (about.[hash].js) for this route
      // which is lazy-loaded when the route is visited.
      component: () => import(/* webpackChunkName: "about" */ './views/About.vue')
    }
  ]
})
