<template>
  <div class="msj_container">
    <div class="page-wrap">
      <!-- Home.vue -->
    <!-- 3.面板 1父面板 4子面板 -->
    <!-- 第一个推荐 -->
    <mt-tab-container v-model="active">
      <mt-tab-container-item id="message">
        <mesagelist>
          
        </mesagelist>
      </mt-tab-container-item>
    </mt-tab-container>
    <!-- 第二个 食话 -->
    <mt-tab-container v-model="active">
      <mt-tab-container-item id="contast">
        <contast>
          
        </contast>
      </mt-tab-container-item>
    </mt-tab-container>
    <!-- 第三个发现 -->
    <mt-tab-container v-model="active">
      <mt-tab-container-item id="find">
       <find>

       </find>
      </mt-tab-container-item>
    </mt-tab-container>
    <!-- 第四个页面 我的-->
     <mt-tab-container v-model="active">
      <mt-tab-container-item id="me">
        <loginme>

        </loginme>
        <logincg></logincg>
      </mt-tab-container-item>
    </mt-tab-container>
    <!-- 底部导航条 -->
    <mt-tabbar v-model="active" fixed>
      <!-- ① -->
      <mt-tab-item id="message" @click.native="changeState(0)">
        <tabbarlcon :selectedImage="require('../../assets/tabbar_01ed.png')" :normalImage="require('../../assets/tabbar_01.png')" :focused="currentIndex[0].isSelect"></tabbarlcon>食集
      </mt-tab-item>
      <!-- ② -->
      <mt-tab-item id="contast" @click.native="changeState(1)">
        <tabbarlcon :selectedImage="require('../../assets/tabbar_04ed@3x.png')" :normalImage="require('../../assets/tabbar_04@3x.png')" :focused="currentIndex[1].isSelect"></tabbarlcon>食秀
      </mt-tab-item>
      <!-- ③ -->
      <mt-tab-item id="find" @click.native="changeState(2)">
        <tabbarlcon :selectedImage="require('../../assets/tabbar_02ed@3x.png')" :normalImage="require('../../assets/tabbar_02@3x.png')" :focused="currentIndex[2].isSelect"></tabbarlcon>发现
      </mt-tab-item>
      <!-- ④ -->
      <mt-tab-item id="me" @click.native="changeState(3)">
        <tabbarlcon :selectedImage="require('../../assets/tabbar_05ed@3x.png')" :normalImage="require('../../assets/tabbar_05@3x.png')" :focused="currentIndex[3].isSelect"></tabbarlcon>我的
      </mt-tab-item>
    </mt-tabbar>
    </div>
  </div>
</template>
<script>
//1.导入顶部导航条子组件
import TabBarIcon from "./common/TabBaricon.vue"
import MesageList from "./common/MesageList.vue"
import LoginMe from "./common/LoginMe.vue"
import Find from "./common/Find.vue"
import Contast from "./common/Contast.vue"
//3.调用顶部导航条子组件
export default {
  //左侧文字 右侧两张图片
  data(){
    return{
      // 子组件id
      active:"message",
      // 使用数组保存图片焦点状态
      currentIndex:[
        {isSelect:true},
        {isSelect:false},
        {isSelect:false},
        {isSelect:false}
      ]
    }
  },
  //2.注册底部导航条子组件
  methods:{
    changeState(n){
      console.log(n);
        // 1:n当前按钮下标
        // 2.创建循环数据
        for(var i=0;i<this.currentIndex.length;i++){
        // 3.如果当前下标与参数下标一致 true
          if(n==i){
            this.currentIndex[i].isSelect=true;
          }else{
          // 4.其他元素 false]
            this.currentIndex[i].isSelect=false;
          }
        }
    },
  },
  components:{
    "tabbarlcon":TabBarIcon,
    "mesagelist":MesageList,
    "loginme":LoginMe,
    "find":Find,
    "contast":Contast
  }
}
</script>
<style scoped>
/* 1.最外层父元素 */
.msj_container{
  overflow:hidden; /*溢出隐藏*/
}
.page-wrap{
  overflow:fixed; /*溢出显示滚动条*/
  padding-bottom:60px;
}
/* 修改tabbar 默认文字颜色 */
.mint-tabbar>.mint-tab-item{
  color:#999999;
}
/* 修改tabbar 选中文字颜色 */
.mint-tabbar>.mint-tab-item.is-selected{
  color:#ff4c39;
  background:transparent;
}
</style>
