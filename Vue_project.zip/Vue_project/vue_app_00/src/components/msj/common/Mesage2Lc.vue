<template>
  <div class="product_app">
    <div class="goods-item" v-for="(item,i) of list" :key="i">
      <a href="javascript:;">
      <img :src="'http://127.0.0.1:3000/img/msj2L/'+item.img_url" alt="">
      <h3>{{item.title}}</h3>
      <p>{{item.subtitle}}</p>
      <div class="product_uname">
        <img :src="'http://127.0.0.1:3000/img/msj2L/'+item.img_uname" alt="">
        <span>{{item.uname}}</span>
      </div>
      </a>
    </div>
  </div>
</template>
<script>
export default {
  data(){
    return{
      list:[],
      pon:0,
      ps:6
    }
  },
  methods:{
    loadMore(){
      // 加载更多
      var url ="product_tree";
      this.axios.get(url).then(result=>{
        console.log(result.data.data);
        this.list = result.data.data
      })
    }
  },
  created(){
    this.loadMore();
  },
}
</script>
<style scoped>
   /* 最外层父元素 */
  .product_app{
    display:flex;
    flex-wrap:wrap;/*子元素换行*/
    justify-content:space-between;
    padding:4px;
    margin:0 3px;
  }
  .product_app .goods-item{
    width:49%;/*元素宽度*/
    border:1px solid #ccc;
    box-sizing:border-box;
    margin:2px 0;
    padding:2px;
    display:flex; /*弹性布局*/
    flex-direction:column;
    min-height:247px;/*高度*/
    border-radius:15px; /*圆角*/
  }
  /* 商品图片，充满父元素 */
  .product_app>.goods-item img{
    width:100%;
    border-radius:13px;
  }
  .product_uname>img{
    width:25px !important;
  }
  .goods-item a{
    
    text-decoration: none;
  }
  .goods-item a>h3{
    color:#222222;
    margin:10px 0;
    padding-left:5px;  
  }
  .goods-item a>p{
    padding-left: 5px;
    color:#444;
    margin:10px 0;
  }
  .goods-item>a>div{
    padding-left:5px;
    color:#000;
    justify-content: center;
  }
  .goods-item>a>div>span{
    margin-left:3px;
    top:-6px;
    position: relative;
  }
</style>
