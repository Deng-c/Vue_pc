<template>
  <div>
    <!-- 1：顶部标题栏子组件 -->
    <titlebar 
    :leftImg="require('../../../assets/jia.png')" :centerImg="require('../../../assets/fangdaj.png')" 
    :rightImg="require('../../../assets/xinx.png')" >
    </titlebar>
    <!-- 2.防止顶部内溢出 -->
    <!-- 保留(标题)48px -->
    <div style="margin-top:54px;"></div>
    <!-- 轮播图组件 -->
    <carousel></carousel>
    <!-- 1L组件 -->
    <mesage1l></mesage1l>
    <!-- 2L组件 -->
    <!-- 2L导航栏 -->
    <!-- <sticky-slot class="stickyTop"> -->
    <div :class="fiex">
      <mt-navbar v-model="active">
        <mt-tab-item id="d1" @click.native="changeState(0)"><span>推荐</span></mt-tab-item>
        <mt-tab-item id="d2" @click.native="changeState(1)"><span>时令</span></mt-tab-item>
        <mt-tab-item id="d3" @click.native="changeState(2)"><span>肉食</span></mt-tab-item>
        <mt-tab-item id="d4" @click.native="changeState(3)"><span>素食</span></mt-tab-item>
        <mt-tab-item id="d5" @click.native="changeState(4)"><span>烘焙</span></mt-tab-item>
      </mt-navbar>
    </div>
    <!-- </sticky-slot> -->
    <!-- 2L详情页 -->
    <mt-tab-container v-model="active">
      <mt-tab-container-item id="d1">
        <mesage2la></mesage2la>
      </mt-tab-container-item>
      <mt-tab-container-item id="d2">
        <mesage2lb></mesage2lb>
      </mt-tab-container-item>
      <mt-tab-container-item id="d3">
        <mesage2lc></mesage2lc>
      </mt-tab-container-item>
      <mt-tab-container-item id="d4">
        <mesage2ld></mesage2ld>
      </mt-tab-container-item>
      <mt-tab-container-item id="d5">
        <mesage2le></mesage2le>
      </mt-tab-container-item>
    </mt-tab-container>
  </div>
</template>
<script scoped>
// better-scroll
import BScroll from "better-scroll"
// 头部
import TitleBar from "./TitleBar.vue"
// 引入轮播图组件
import 'swiper/dist/css/swiper.css'
import {swiper,swiperSlide} from 'vue-awesome-swiper'
import Carousel from "./Carousel.vue"
// 引入1L组件
import Mesage1L from "./Mesage1L.vue"
// 引入2L组件
import Mesage2La from "./Mesage2La.vue"
import Mesage2Lb from "./Mesage2Lb.vue"
import Mesage2Lc from "./Mesage2Lc.vue"
import Mesage2Ld from "./Mesage2Ld.vue"
import Mesage2Le from "./Mesage2Le.vue"
export default {
  data(){
    return{
      active:"d1",
      fiex:{fixed:false}
    }
  },
  components:{
    "titlebar":TitleBar,
    "carousel" :Carousel,
    swiper,swiperSlide,
    "mesage1l":Mesage1L,
    "mesage2la":Mesage2La,
    "mesage2lb":Mesage2Lb,
    "mesage2lc":Mesage2Lc,
    "mesage2ld":Mesage2Ld,
    "mesage2le":Mesage2Le,
  },
  // 注册2L导航条子组件
  methods:{
    changeState(n){
      console.log(n);
    },
  },
  created(){
    window.onscroll=()=>{
        if(window.scrollY>468){
          this.fiex.fixed=true;
        }else{
          this.fiex.fixed=false;
        }
    }
  }
}
</script>
<style scoped>
  .mint-tab-item.mint-tab-item.is-selected{
    color:#ff4c39;
    border-bottom:3px solid #ff4c39;
  }
  .mint-tab-item-label span{
    font-size:15px !important;
    /* color:#222; */
  }
  .mint-navbar{
    margin:0 3px;
  }
  .fixed{
    position:fixed;
    top:42px;
    z-index:102;
    width:100%
  }
</style>
