<template>
  <div>
    <div class="two_header">
      <a href="javascript:;"><img src="../../../assets/two_jia.png" alt=""></a>
      <h3>食秀</h3> 
      <a href="javascript:;"><img src="../../../assets/two_fa.png" alt=""></a>  
      <a href="javascript:;"><img src="../../../assets/two_w.png" alt=""></a>  
    </div>
    <!-- swiper -->
    <swiper :options="swiperOption" style="padding-top:44px;">
      <swiper-slide v-for="(item,i) of list" :key="i">
        <img :src="'http://127.0.0.1:3000/img/carousel/'+item.img_url" alt="">
      </swiper-slide>
      <div class="swiper-pagination" slot="pagination"></div>
    </swiper>
    <div class="contast_1L">
      <ul>
        <li >
          <a href="javascript:;"></a>
          <span>餐桌美食</span>
        </li>
        <li >
          <a href="javascript:;"></a>
          <span>玩转烘焙</span>
        </li>
        <li >
          <a href="javascript:;"></a>
          <span>美食课堂</span>
        </li>
        <li >
          <a href="javascript:;"></a>
          <span>最IN活动</span>
        </li>
      </ul>
    </div>
    <!-- 2L -->
    <div class="contast_2L">
    <mt-navbar v-model="active">
      <mt-tab-item id="contast_2a"><span>最新</span></mt-tab-item>
      <mt-tab-item id="contast_2b"><span>最热</span></mt-tab-item>
    </mt-navbar>
    <!-- tab-container -->
    <mt-tab-container v-model="active">
      <mt-tab-container-item id="contast_2a">
        <div v-for="(item,i) of list2" :key="i" class="contast_2L_body">
          <img :src="'http://127.0.0.1:3000/img/contast-2L-header/'+item.img_uname" alt="">
          <div>
            <span> {{item.uname}}</span><br>
            <em> {{item.utime}}</em>
          <a href="javascript:;">
            <p>{{item.title}}</p>
            <img :src="'http://127.0.0.1:3000/img/contast-2L/'+item.img1_url" alt="">
            <img :src="'http://127.0.0.1:3000/img/contast-2L/'+item.img2_url" alt="">
            <img :src="'http://127.0.0.1:3000/img/contast-2L/'+item.img3_url" alt="">
            <img :src="'http://127.0.0.1:3000/img/contast-2L/'+item.img4_url" alt="">
            <img :src="'http://127.0.0.1:3000/img/contast-2L/'+item.img5_url" alt="">
            <img :src="'http://127.0.0.1:3000/img/contast-2L/'+item.img6_url" alt="">
          </a>
          <div>
            <img :src="'http://127.0.0.1:3000/img/contast-2L-header/'+item.img_word" alt="">
            <span> {{item.word}} </span>
            <img :src="'http://127.0.0.1:3000/img/contast-2L-header/'+item.img_collect" alt="">
            <span> {{item.collect}}</span>
          </div>
          </div>
        </div>
      </mt-tab-container-item>
      <mt-tab-container-item id="contast_2b">
        <div v-for="(item,i) of list3" :key="i" class="contast_2L_body">
          <img :src="'http://127.0.0.1:3000/img/contast-2L-header/'+item.img_uname" alt="">
          <div>
            <span> {{item.uname}}</span><br>
            <em> {{item.utime}}</em>
          <a href="javascript:;">
            <p>{{item.title}}</p>
            <img :src="'http://127.0.0.1:3000/img/contast-2L/'+item.img1_url" alt="">
            <img :src="'http://127.0.0.1:3000/img/contast-2L/'+item.img2_url" alt="">
            <img :src="'http://127.0.0.1:3000/img/contast-2L/'+item.img3_url" alt="">
            <img :src="'http://127.0.0.1:3000/img/contast-2L/'+item.img4_url" alt="">
            <img :src="'http://127.0.0.1:3000/img/contast-2L/'+item.img5_url" alt="">
            <img :src="'http://127.0.0.1:3000/img/contast-2L/'+item.img6_url" alt="">
          </a>
          <div>
            <img :src="'http://127.0.0.1:3000/img/contast-2L-header/'+item.img_word" alt="">
            <span> {{item.word}} </span>
            <img :src="'http://127.0.0.1:3000/img/contast-2L-header/'+item.img_collect" alt="">
            <span> {{item.collect}}</span>
          </div>
          </div>
        </div>
      </mt-tab-container-item>
    </mt-tab-container>
    </div>
  </div>
</template>
<script>
export default {
  data(){
    return{
      // fiex2:{fixed:false},
      active:"contast_2a",
      swiperOption: {
          slidesPerView: 1,
          spaceBetween: 30,
          loop: true,
          autoplay:true,    
          observer:true,//修改swiper自己或子元素时，自动初始化swiper 
　　       observeParents:true,
          pagination: {
            el: '.swiper-pagination',
            clickable: true
          },
          navigation: {
          }
        },
        list:[],
        list2:[],
        list3:[]
    }
  },
  methods:{
    loadMore(){
      var url="/contast";
      this.axios.get(url).then(result=>{
        // console.log(result.data)
        this.list=result.data;
      });
      var url="/contast2";
      this.axios.get(url).then(result=>{
        // console.log(result.data)
        this.list2=result.data;
      });
      var url="/contast3";
      this.axios.get(url).then(result=>{
        // console.log(result.data)
        this.list3=result.data;
      });
    }
  },
  created(){
    this.loadMore();
    // window.onscroll=()=>{
    //   if(window.scrollY>487){
    //     this.fiex.fixed=true;
    //   }else{
    //     this.fiex.fixed=false;
    //   }
    // }
  }
}
</script>
<style scoped>
/* 头部 */
  .two_header{
    display: flex;
    height:44px;
    position:fixed;
    z-index: 10;
    background: url("../../../assets/bj.jpg")
  }
  .two_header>h3{
    width: 100%;
    margin:0;
    text-align: center;
    line-height: 44px;
  }
  .two_header>a>img{width:70%;}
  .two_header>a:nth-child(3){
    position: relative;
    left:21px;
  }
  .swiper-slide>img{
    width:100%;
  }
  /* contast 轮播图下1L 样式 */
  .contast_1L>ul{
    display:flex;
    margin:0;
    padding:0;
  }
  .contast_1L>ul>li{
    list-style: none;
    width:25%;
    text-align: center;
    font-size:12px;
    
  }
  .contast_1L>ul>li>a{
    width:100%;
    padding-top:100%;
    height:0;
    display: block;
  }
  .contast_1L>ul>li:nth-child(1)>a{
    background:url(../../../assets/zhms1.png) no-repeat center;
    background-size:80% auto;
  }
  .contast_1L>ul>li:nth-child(2)>a{
    background:url(../../../assets/bake1.png) no-repeat center;
     background-size:80% auto;
  }
  .contast_1L>ul>li:nth-child(3)>a{
    background:url(../../../assets/question1.png) no-repeat center;
     background-size:80% auto;
  }
  .contast_1L>ul>li:nth-child(4)>a{
    background:url(../../../assets/exercise1.png) no-repeat center;
     background-size:80% auto;
  }
  /* 2L样式 */
  /* .fiex2{
    z-index: 11;
    position:fixed;
    top:42px;
    width:100%;
  } */
  .contast_2L>div>a:first-child{
    text-align:right;
  }
  .contast_2L>div>a:last-child{
    text-align: left;
  }
  .mint-tab-item-label >span{
    font-size:16px !important; 
    padding:5px;
  }
  .mint-navbar .mint-tab-item.is-selected {
    color:#ff4c39;
    border-bottom:0;
  }
  /* 2L主体样式 */
  .contast_2L_body{
    padding:0px 5%;
    box-sizing: border-box;
    margin-top:-30px;
  }
  .contast_2L_body>img{
    width:35px;
    position: relative;
    top:40px;
  }
  .contast_2L_body>div{
    padding-left:40px;
    position:relative;
  }
  .contast_2L_body>div>span{
    color:#ff4c39;
    position: relative;
 
  }
  .contast_2L_body>div>em{
    color:#999;
    position:relative;
    font-size:14px;
  }
  .contast_2L_body>div>a{
    text-decoration: none;
  }
  .contast_2L_body>div>a>p{
    margin: 0;
    color:#000;
    position: relative;
    line-height: 24px;
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
  }
  .contast_2L_body>div>a>img{
    padding:5px;
    width:30%;
  }
  .contast_2L_body>div>div{
    text-align: right;
  }
  .contast_2L_body>div>div>img{
    width:15px;
  }
  .contast_2L_body>div>div>span{
    color:#999;
  }
</style>
