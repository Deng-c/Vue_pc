<template>
  <div class="loginme">
    <div class="loginme_header"> 
    </div>
    <div class="login">
      <img src="../../../assets/shij.jpg" alt="">
      <div class="uname">
        <img src="../../../assets/loginw.png" alt="">
        <mt-field v-model="uname" type="text" placeholder="请输入您的账号"></mt-field>
      </div>
      <div class="pwd">
        <img src="../../../assets/pwd.png" alt="">
        <mt-field v-model="upwd" type="password" placeholder="请输入您的密码"></mt-field>
      </div>
      <mt-button @click="login">登录</mt-button>
      <div>
        <a href="">注册账号</a>
        <a href="">忘记密码？</a>
      </div>
      <div>
        <p>第三方账号登录</p>
        <img src="../../../assets/weixin.png" alt="">
        <img src="../../../assets/QQ.png" alt="">
        <img src="../../../assets/wb.png" alt="">
      </div>
    </div>
  </div>
</template>
<script>
export default {
  data(){
    return{
      uname:"",
      upwd:"",
    }
  },
  methods:{
    login(){
      // 完成登录
      // 1.获得用户名和密码
      var u = this.uname;
      var p = this.upwd;
      // 2.创建一个正则表达式，字母数字下滑先3~12
      var reg = /^[a-z0-9_A-Z]{3,12}$/i;
      // 3.验证用户名 出错提示
      if(!reg.test(u)){
        this.$toast("用户名格式不正确");
        return;
      }
      // 4.验证密码 出错提示
      if(!reg.test(p)){
        this.$toast("密码格式不正确");
        return;
      }
      // 5.发送ajax请求
      var url = "login";
      var obj = {uname:u,upwd:p};
      this.axios.get(url,{params:obj}).then(result=>{console.log(result.data.code);
      // 1.判断服务器返回结果
      // 2.code:>0 跳转Home组件
      if(result.data.code>0){
        this.$router.push("./Logincg")
      }else{
        this.$messagebox("提示","用户名或密码有误");
      }
      // 3.创建Home.vue组件
      // 4.code<0 交互提示框
      })
    }
  }
}
</script>
<style scoped>
  .loginme{
    height:600px;
  }
  .loginme_header{  
    background: url(../../../assets/home_bgOnline@3x.png) center no-repeat;
    background-size: 100% 100%;
    height:200px;
  }
  
  .login{
    margin:0 auto;
    text-align: center;
    width:90%;
    background:#f5f5f5;
    position: relative;
    top:-60px;
    border-radius: 40px;
    height:28rem;
  }
  .login>img:first-child{
    width:100px;
    position: relative;
    top:-35px;
    border-radius: 25px;
  }
  .login>.uname>img,.login>.pwd>img{
    width:30px;
    position: relative;
    left:-39%;
    top:39px;
    z-index: 10;
  }
  .login>button{
    margin:20px auto;
    display: block;
    width:90%;
    font-size:17px;
    padding:10px 50px;
    background:linear-gradient(left,#ff9a80 0%,#ff4c39 100%);
    border:0;
    border-radius:50px;
    color:#fff;
  }
  .login>div>a{
    text-decoration: none;
    color:#555555;
  }
  .login>div>a:first-child{
    margin-right:15%;
  }
  .login>div>a:last-child{
    margin-left:15%;
  }
  .login>div>img{
    width:30px;
    padding:0 10px;
  }
  p{margin:10px 0;}
</style>
