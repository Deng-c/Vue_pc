<template>
  <div class="logincg">
    <div class="login_1">
      <img src="../../../assets/touxiang.jpg" alt="">
      <p>tom</p>
      <p>正在通往美食达人的路上...</p>
      <a>美食杰DNA 0条 ></a>
    </div>
    <ul class="login_2">
      <li>0关注</li>
      <li>0粉丝</li>
      <li>0菜谱</li>
    </ul>
    <p>荣誉勋章</p>
    <ul class="login_3">
      <li><img src="../../../assets/sousuo.png" alt=""></li>
      <li><img src="../../../assets/caipu1.png" alt=""></li>
      <li><img src="../../../assets/kouwei1.png" alt=""></li>
      <li><img src="../../../assets/caixi1.png" alt=""></li>
      <li><img src="../../../assets/zucai1.png" alt=""></li>
      <li><img src="../../../assets/gexing1.png" alt=""></li>
      <li><img src="../../../assets/zuopin1.png" alt=""></li>
    </ul>
    <ul class="login_4">
      <li>
        <img src="../../../assets/jife.png" alt="">
        <a href="">积分商城</a><span>></span> 
      </li>
      <li>
        <img src="../../../assets/xiaox.png" alt="">
        <a href="">消息通知</a><span>></span> 
      </li>
      <li>
        <img src="../../../assets/fabu.png" alt="">
        <a href="">我的发布</a><span>></span> 
      </li>
      <li>
        <img src="../../../assets/xin.png" alt="">
        <a href="">我的收藏</a> <span>></span> 
      </li>
      <li>
        <img src="../../../assets/wode.png" alt="">
        <a href="">我的订单</a><span>></span> 
      </li>
      <li>
        <img src="../../../assets/wom.png" alt="">
        <a href="">关于我们</a><span>></span> 
      </li>
    </ul>
  </div>
</template>
<script>
export default {
  data(){
    return{}
  }
}
</script>
<style scoped>
  *{padding:0;margin:0;}

  /* 头部 */
  .login_1{
    background: url(../../../assets/home_bgOnline@3x.png) center no-repeat;
  }
  .login_1>img{
    width:72px;
    border-radius: 50%;
    border:3px solid rgba(255, 255, 255, 0.5);;
    position: relative;
    top:31px;
    left:10%;
  }
  .login_1>p{
    margin:5px;
    position: relative;
    top:-44px;
    left:32%;
  }
  .login_1>p:nth-child(2){
    font-size: 24px;
    color:#fff;
    line-height:24px;
    overflow:hidden;
    font-weight: 700;
  }
  .login_1>p:nth-child(3){
    font-size: 12px;
    line-height:24px;
    color:#fff;
  }
  .login_1>a{
    padding:5px 10px;
    border-radius: 40px;
    color:#fff;
    background:rgba(255, 255, 255, 0.2);
    border:1px solid rgba(255, 255, 255, 0.3);;
    position: relative;
    top:-33px;
    left:32%;
    font-size:12px;
  }
  /* 第二部分 login_2*/
  li{
    list-style: none;
  }
  .login_2{
    width:100%;
    height:44px;
    background:#f5f5f5;
    margin-bottom:10px;
    position: relative;
    top:-14px;
  }
  .login_2>li{
    text-align: center;
    display: inline-block;
    width:33%;
    line-height: 44px;
    color:#666;
  }
  /* 第三部分  login_3 */
  .login_2+p{
    color:#333;
    background:#f5f5f5;
    padding:5px 3%;
  }
  .login_3{
    background:#f5f5f5;
    padding:5px 3%;
  }
  .login_3>li{
    text-align: center;
    display:inline-block;
    width:14%;
  }
  .login_3>li>img{
    width:38px;
  }
  /* 第四部分 login_4 */
  .login_4>li>img{
    width:27px;
    padding-left:5px;
    position: relative;
    top:6px;
  }
  .login_4>li{
    background:#f5f5f5;
    margin:10px 0;
    height:45px;
  }
  .login_4>li>a{
    text-decoration: none;
    display: inline-block;
    padding-left:3px;
    color:#444;
  }
  .login_4>li>span{
    font-size:20px;
    font-weight: 500;
    position:relative;
    right:-66%;
  }
</style>
