<template>
  <div>
    <a href="http://127.0.0.1:8080/#/Home1" id="home">＜ 美食杰</a>
    <div v-for="(item,i) of list" :key="i">
      <!-- 详情 -->
      <div class="header">
        <img :src="'http://127.0.0.1:3000/img/particular/01/'+item.img_url" alt="">
        <div>
          <h3>{{item.title}}</h3>
          <span>{{item.collect}}</span>
          <span>{{item.browse}}</span>
        </div>
      </div>
      <div class="uname">
        <img :src="'http://127.0.0.1:3000/img/particular/01/'+item.img_name" alt="">
        <span>{{item.uname}}</span>
        <span>{{item.issue}}</span>
        <a href="javascript:;">{{item.concern}}</a>
        <p>{{item.details}}</p>
      </div>
      <div>
        <div class="grade">
          <span>{{item.grade}}</span>
          <img :src="'http://127.0.0.1:3000/img/particular/01/'+item.img1" alt="">
          <img :src="'http://127.0.0.1:3000/img/particular/01/'+item.img1" alt="">
          <img :src="'http://127.0.0.1:3000/img/particular/01/'+item.img1" alt="">
          <img :src="'http://127.0.0.1:3000/img/particular/01/'+item.img1" alt="">
          <img :src="'http://127.0.0.1:3000/img/particular/01/'+item.img1" alt="">
        </div>
        <div class="utime">
          <img :src="'http://127.0.0.1:3000/img/particular/01/'+item.img_word" alt="">
          <span>{{item.word}}</span>
          <img :src="'http://127.0.0.1:3000/img/particular/01/'+item.img_coll" alt="">
          <span>{{item.coll}}</span> <br>
          <img :src="'http://127.0.0.1:3000/img/particular/01/'+item.img_utime" alt="">
          <span>{{item.utime}}</span>
        </div>
      </div>
      <div class="main">
        <p>{{item.main}} <span>两人份</span></p>
        <p>{{item.main_1}}</p>
        <p>{{item.fu}}</p>
        <p>{{item.fu_1}}</p>
      </div>
    </div>
    <!-- 具体操作步骤 -->
    <div v-for="(item,i) of list2" :key="i" class="step">
      <div>
        <p>{{item.step01}}</p>
        <img :src="'http://127.0.0.1:3000/img/particular/01/'+item.img_step01" alt="">
        <p>{{item.step01_content}}</p>
      </div>
      <div>
        <p>{{item.step02}}</p>
        <img :src="'http://127.0.0.1:3000/img/particular/01/'+item.img_step02" alt="">
        <p>{{item.step02_content}}</p>
      </div>
      <div>
        <p>{{item.step03}}</p>
        <img :src="'http://127.0.0.1:3000/img/particular/01/'+item.img_step03" alt="">
        <p>{{item.step03_content}}</p>
      </div>
      <div>
        <p>{{item.step04}}</p>
        <img :src="'http://127.0.0.1:3000/img/particular/01/'+item.img_step04" alt="">
        <p>{{item.step04_content}}</p>
      </div>
      <div>
        <p>{{item.step05}}</p>
        <img :src="'http://127.0.0.1:3000/img/particular/01/'+item.img_step05" alt="">
        <p>{{item.step05_content}}</p>
      </div>
      <div>
        <p>{{item.step06}}</p>
        <img :src="'http://127.0.0.1:3000/img/particular/01/'+item.img_step06" alt="">
        <p>{{item.step06_content}}</p>
      </div>
  
      <!-- 成品图 -->
      <div class="product">
        <p>{{item.product_title}}</p>
        <img :src="'http://127.0.0.1:3000/img/particular/01/'+item.product_1" alt="">
        <img style="display:none;" :src="'http://127.0.0.1:3000/img/particular/01/'+item.product_2" alt="">
        <img style="display:none;" :src="'http://127.0.0.1:3000/img/particular/01/'+item.product_3" alt="">
        <img style="display:none;" :src="'http://127.0.0.1:3000/img/particular/01/'+item.product_4" alt="">
        <div>
          <div>
          <img :src="'http://127.0.0.1:3000/img/particular/01/'+item.product_1" alt="">
          </div>
          <div>
          <img :src="'http://127.0.0.1:3000/img/particular/01/'+item.product_2" alt="">
          </div>
          <div>
           <img :src="'http://127.0.0.1:3000/img/particular/01/'+item.product_3" alt="">
          </div>
          <div>
           <img :src="'http://127.0.0.1:3000/img/particular/01/'+item.product_4" alt="">
          </div>
        </div>
        <p><strong>烹饪技巧</strong> <br> 小米粥既开胃又养胃，加些山药效果更好哦<br>苏泊尔电压力锅一键预约，大大节省了时间<br><span>原创菜谱创建时间：2019-07-11 18:25:20</span></p>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  data(){
    return{
      list:[],
      list2:[]
    }
  },
  methods:{
    loadMore(){
      var url ="/particular";
      this.axios.get(url).then(result=>{
        this.list=result.data;
      });
      var url ="/particular_2";
      this.axios.get(url).then(result=>{
        this.list2=result.data;
      })
    }
  },
  created(){
    this.loadMore();
  }
}
</script>
<style scoped>
  *{margin:0;padding:0;}
  #home{
    text-decoration: none;
    position:fixed;
    z-index: 10;
    background:rgba(0,0,0, 0.5);
    color:#fff;
    padding:4px 12px;
    font-size:14px;
    top:15px;
    left:15px;
    border-radius:50px;
  }
  /* 第一部分 header*/
  .header{
    width:100%;
  }
  .header>img{
    width: 100%;
  }
  .header>div{
    background:#fff4d6;
    width:100%;
    height:6rem;
  }
  .header>div>h3{
    padding:20px 5%;
    padding-bottom:10px;
    font-size:24px;
    color:#000;
  }
  .header>div>span{
    box-sizing: border-box;
    padding: 0px 3px 0px 5%;
    font-size:14px;
  }
  .header>div>span:last-child{
    padding-left:5px;
  }
  /* 第二部分 uname */
  .uname{
    padding:5px 3%;
    padding-top:15px;
  }
  .uname>img{
    width:40px;
    border-radius: 50%;
  }
  .uname>span:nth-child(2){
    font-size:14px;
    top:-20px;
    padding-left:5px;
    position: relative;
    color:#555;
  }
  .uname>span:nth-child(3){
    font-size:12px;
    position: relative;
    left:-54px;
    color:#999;
  }
  .uname>a{
    position: relative;
    right:-28%;
    top:-14px;
    font-size: 14px;
    padding:5px 15px;
    border:1px solid #ff4c39;
    border-radius: 50px;
    color:#ff4c39;
    text-decoration: none;
  }
  .uname>p{
    padding: 6px 0;
    font-size:17px;
    color:#333;
    font-weight: 300;
    line-height: 25px;
  }
  /* 第三部分 grade */
  .grade{
    padding:0 3%;
  }
  .grade>span{
    font-size:16px;
    padding-right:5px;
    font-weight: 900;
  }
  .grade>img{
    width:15px;
    padding:0 3px;
  }
  /* 第四部分 utime */
  .utime{
    padding:5px 3%;
  }
  .utime>img{
    width:24px;
  }
  .utime>span{
    font-size: 16px;
    padding-left:5px;
    color:#666;
    top:-5px;
    position: relative;
  }
  .utime>img:nth-child(3){
    margin-left:20%;
  }
  /* 第五部分 main */
  .main{
    padding:5px 3%;
  }
  .main>p:first-child,.main>p:nth-child(3){
    font-size:16px;
    color:#333;
    font-weight: 900;
    padding:10px 0;
  }
  .main>p:first-child>span{
    font-size:14px;
    color:#999;
    font-weight: 500;
  }
  .main>p:nth-child(2),.main>p:last-child{
    font-size:16px;
    color:#333;
    font-weight: 300;
  }
  /* 详细操作步骤 step */
  .step>div>p:first-child{
    margin:30px 0px 10px;
    font-size:19px;
    font-weight: 500;
    text-align: center;
  }
  .step>div>img{
    width:100%;
  }
  .step>div>p:last-child{
    margin:16px 20px;
    font-size:17px;
    text-align:justify;
    color:#555;
  }
  /* 成品图 */
  .product>p{
    margin:30px 0px 10px;
    font-size:19px;
    font-weight: 500;
    text-align: center; 
  }
  .product>img{
    width:100%;
  }
  .product>div{
    margin-top:20px;
    margin-bottom: 10px;
    display:flex;
    padding:0 2%;
  }
  .product>div>div>img{
    margin:0 auto;
    box-sizing: border-box;
    padding:0px 2%;
    width:100%;
    height:70px;
  }
  .product>div>p{
    margin:10px 3%;
    line-height: 25px;
    font-size:17px;
  }
  .product>p:last-child>span{
    font-size: 12px;
    margin-top:10px;
  }
</style>
