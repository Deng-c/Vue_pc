<template>
  <md-card>
    <md-card-actions>
      <div class="md-subhead">
        <span>“ 我只有这点本事，“喂”你开心</span>
      </div>
    </md-card-actions>
    <md-card-media class="swiper-inner">
      <!-- swiper -->
      <swiper :options="swiperOption">
        <swiper-slide>
          <img :src="require('../../../assets/a-1.jpg')" alt="">
          <div>
            <h3 class="title">金蒜蒸丝瓜</h3>
            <p class="subtitle">富含维生素，清热解暑</p>
          </div>
        </swiper-slide>
        <swiper-slide>
          <img :src="require('../../../assets/a-2.jpg')" alt="">
          <div>
            <h3 class="title">酱蒸排骨</h3>
            <p class="subtitle">富含优质蛋白，多吃健脾胃</p>
          </div>
        </swiper-slide>
        <swiper-slide>
          <img :src="require('../../../assets/a-3.jpg')" alt="">
          <div>
            <h3 class="title">黄瓜水晶凉皮</h3>
            <p class="subtitle">富含碳水化合物，清凉解暑</p>
          </div>
        </swiper-slide>
        <swiper-slide>
          <img :src="require('../../../assets/a-4.jpg')" alt="">
          <div>
            <h3 class="title">卤肉夹馍</h3>
            <p class="subtitle">富含氨基酸，提高免疫力</p>
          </div>
        </swiper-slide>
        <swiper-slide>
          <img :src="require('../../../assets/a-5.jpg')" alt="">
          <div>
            <h3 class="title">西瓜冰粥</h3>
            <p class="subtitle">富含氨基酸，解暑生津</p>
          </div>
        </swiper-slide>
        <swiper-slide>
          <img :src="require('../../../assets/a-6.jpg')" alt="">
          <div>
            <h3 class="title">哈密瓜雪糕</h3>
            <p class="subtitle">生津止渴，补充维生素</p>
          </div>
        </swiper-slide>
        <div class="swiper-scrollbar" slot="scrollbar"></div>
      </swiper>
    </md-card-media>
  </md-card>
</template>

<script>
  import messagejson from "../json/messagelist.json"
  export default {
    data() {
      return {
        list:messagejson,
        props:{
          title:{default:""},
          subtitle:{default:""}
        },
        swiperOption: {
          effect: 'coverflow',
          grabCursor: true,
          centeredSlides: true,
          slidesPerView: 'auto',
          spaceBetween: 30,
          loop: true,
          coverflowEffect: {
            rotate: 50,
            stretch: 0,
            depth: 100,
            modifier: 1,
            slideShadows : true
          },
          scrollbar: {
            el: '.swiper-scrollbar',
            hide: true
          },
          autoplay: {
            delay: 2500,
            disableOnInteraction: false
          },
        },
        methods:{
          
        }
      }
    }
  }
</script>

<style scoped>
  .swiper-container{margin:0 3px;}
  .md-subhead{
    margin:0.5rem 1rem;
    font-size:16px;
    background:linear-gradient(to right,#ade873 0%,#ff4c39 100%);
    background-clip:text;
    -webkit-background-clip: text;
    text-fill-color: transparent;
    -webkit-text-fill-color: transparent;
  }
  .swiper-inner {
    width: 100%;
    height: 300px;
    padding-top:50px;
  }
  .swiper-slide {
    background-position: center;
    background-size: cover;
    width: 300px;
    height: 300px;
  }
  .swiper-slide>div{
    width:22rem;
    background-color:rgba(200, 200, 200, 0.4);
    position: absolute;
    bottom:0;
  }
  .swiper-slide>div>h3{
    margin:10px 0;
    color:#333;
    padding-left:10px;
  }
  .swiper-slide>div>p{
    padding-left:10px;
    margin:5px 0px 15px 0px;
  }
</style>