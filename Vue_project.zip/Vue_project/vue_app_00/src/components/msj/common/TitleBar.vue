<template>
  <div class="page-head">
    <div class="left-head">
      <img :src="leftImg" alt="" style="width:25px;height:20px;">
    </div>
    <div  class="center-head">
      <img :src="centerImg" alt="" style="width:25px;height:25px;">
      <input type="text" placeholder="搜索百万免费菜谱">
    </div>
    <div   class="right-head">
      <img :src="rightImg" alt="" style="width:25px;height:20px;">
    </div>
  </div>
</template>
<script>
export default {
  // 图片
  props:{
    leftImg:{default:""},
    centerImg:{default:""},
    rightImg:{default:""},
  },
  data(){
    return{}
  }
}
</script>
<style scoped>
  /* 1.最外层父元素 */
  .page-head{
    position: fixed;
    box-sizing: border-box;
    z-index:999;
    top:0;
    width:100%;
    line-height: 44px;
    padding-left:7px;
    padding-right:7px;
    background-image: url("../../../assets/bj.jpg");
    height:44px;

  }
  .left-head{
    position: absolute;
    top:4px;
  }
  .center-head{
    margin:0 35px;
  }
  .center-head>img{ 
    position: absolute;
    top:10px;
    left:50px;
  }
  .center-head>input{
    width:100%;
    box-sizing: border-box;
    height:32px;
    padding-left:35px;
    border-radius:3px;
    border:0px;
    color:#555;
    background:#f1f1f1;
  }
  .right-head{
    position: absolute;
    right:10px;
    top:5px;
  }
</style>
