<template>
  <div>
    <!-- 头部 -->
    <div class="find_header">
      <img src="../../../assets/jia.png" alt="">
      发现最热门
      <img src="../../../assets/xinx.png" alt="">
    </div>
    <!-- 1L -->
    <div class="find_1L">
      <a href="javascript:;"><img src="../../../assets/ms_home_find_shicai@3x.png" alt=""></a>
      <a href="javascript:;"><img src="../../../assets/ms_home_find_caidan@3x.png" alt=""></a>
      <a href="javascript:;"><img src="../../../assets/ms_home_find_zhuanti@3x.png" alt=""></a>
      <a href="javascript:;"><img src="../../../assets/ms_home_find_wenzhang@3x.png" alt=""></a>
    </div>
    <!-- 2L -->
    <div>
      <div v-for="(item,i) of list" :key="i" class="find_2L">
        <a href="javascript:;">
        <div>
          <p>{{item.header}}</p>
          <span>{{item.tally}}</span>
        </div>
        <div>
          <img :src="'http://127.0.0.1:3000/img/Find2L/'+item.img_url" alt="">
          <div>
            <span>{{item.uname}}</span>
            <div>
              <img :src="'http://127.0.0.1:3000/img/Find2L/'+item.img1" alt="">
              <img :src="'http://127.0.0.1:3000/img/Find2L/'+item.img2" alt="">
              <img :src="'http://127.0.0.1:3000/img/Find2L/'+item.img3" alt="">
              <img :src="'http://127.0.0.1:3000/img/Find2L/'+item.img4" alt="">
              <img :src="'http://127.0.0.1:3000/img/Find2L/'+item.img5" alt="">
            </div>
            <img :src="'http://127.0.0.1:3000/img/Find2L/'+item.img_word" alt="">
            <span> {{item.word}}</span><br>
            <img :src="'http://127.0.0.1:3000/img/Find2L/'+item.img_collect" alt="">
            <span> {{item.collect}}</span>
          </div>
        </div>
        </a>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  data(){
    return{
      list:[]
    }
  },
  methods:{
    loadMore(){
      var url = "/find2";
      this.axios.get(url).then(result=>{
        this.list=result.data;
      })
    }
  },
  created(){
    this.loadMore();
  }
}
</script>
<style scoped>
  *{margin:0;padding:0;}
  body{background:#f0f0f0; }
  /* 头部样式 */
  .find_header{
    background: url(../../../assets/bj.jpg);
    height:44px;
    text-align: center;
    position:fixed;
    line-height: 44px;
    width:100%;
    font-size:18px;
    z-index: 10;
  }
  .find_header>img:first-child{
    position: absolute;
    left:14px;
    top:9px;
    width:25px;
  }
  .find_header>img:last-child{
    position: absolute;
    right:14px;
    top:9px;
    width:25px;
  }
  /* 1L样式 */
  .find_1L{
    width: 100%;
    padding-top:44px;
    padding-left:2%;
    padding-right: 2%;
  }
  .find_1L>a{
    width:100%;
    box-sizing: border-box;
  }
  .find_1L>a>img{
    width:24%;
    padding:5px 1%;
    box-sizing: border-box;
  }
  /* 2L样式 */
  .find_2L{
    border-top:1px solid #ddd;
    border-bottom: 1px solid #ddd;
    padding:5px 3%;
    margin-top:10px;
  }
  .find_2L>a{
    display: block;
    text-decoration: none;
  }
  .find_2L>a>div>p{
    margin-top:4px; 
    font-size:16px;
    color:#000;
  }
  .find_2L>a>div>span{
    margin:5px 0;
    padding:2px 5px;
    color:#01a1ea;
    font-size:12px;
    border:1px solid #01a1ea;
    display: inline-block;
    border-radius: 3px;
  }
  .find_2L>a>div>img{
    width:30%;
    display: inline-block;
  }
  .find_2L>a>div>div{
    width:70%;
    display:inline-block;
    box-sizing: border-box;
    padding-left:7px;
    position: relative;
    top:-19px;
  }
  .find_2L>a>div>div>span{
    font-size:16px;
    color:#333;
  }
  .find_2L>a>div>div>div{
    margin:2px 0;
  }
  .find_2L>a>div>div>div>img{
    width: 14px;
    height: 14px;
  }
  .find_2L>a>div>div>img{
    width:17px;
    margin:2px 0;
  }
  .find_2L>a>div>div>img+span{
    font-size:15px;
    position: relative;
    top:-6px;
  }
</style>
