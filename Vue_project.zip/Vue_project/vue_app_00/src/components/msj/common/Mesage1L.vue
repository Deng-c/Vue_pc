<template>
  <div class="mesage1L">
    <a href="javascript:;">菜谱分类</a>
    <a href="javascript:;">视频菜谱</a>
    <a href="javascript:;">早餐</a>
    <a href="javascript:;">附近</a>
  </div>
</template>
<script>
export default {
  data(){
    return{}
  }
}
</script>
<style>
  .mesage1L>a:first-child{
    background:url("../../../assets/b-1.png") center top no-repeat;
    background-size:100% auto;
  }
  .mesage1L>a:nth-child(2){
    background:url("../../../assets/b-2.png") center top no-repeat;
    background-size:100% auto;
  }
  .mesage1L>a:nth-child(3){
    background:url("../../../assets/b-3.png") center top no-repeat;
    background-size:100% auto;
  }
  .mesage1L>a:last-child{
    background:url("../../../assets/b-4.png") center top no-repeat;
    background-size:100% auto;
  }
  .mesage1L{
    width:100%;
    margin:0px auto;
    font-size:0px;
    padding-top:24px;
  }
  .mesage1L>a{
    display: inline-block;
    vertical-align: top;
    width:19%;
    margin:0 3%;
    line-height:32px;
    font-size:12px;
    padding-top:19%;
    color:#333;
    text-align: center;
    text-decoration: none;
  }
</style>
