<template>
  <div>
    <!--  -->
    <img :src="focused?selectedImage:normalImage" class="imgstyle" alt="">
  </div>
</template>
<script>
export default {
  data(){
    return{}
  },
  props:{
    focused:false,
    selectedImage:{default:""},
    normalImage:{default:""}
  }
}
</script>
<style>
  .imgstyle{
    width:30px;
    height:30px;
  }
</style>
