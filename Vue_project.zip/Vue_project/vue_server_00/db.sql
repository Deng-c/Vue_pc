#连接utf8
SET NAMES UTF8;
#删除数据库
DROP DATABASE IF EXISTS msj;
#创建数据库
CREATE DATABASE msj CHARSET=UTF8;
#进入数据库
USE msj;
#创建登录表
CREATE TABLE msj_login(
  id INT PRIMARY KEY AUTO_INCREMENT,
  uname VARCHAR(50),
  upwd  VARCHAR(32)
);
INSERT INTO msj_login VALUES(null,'tom',md5('123'));

#轮播图
CREATE TABLE msj_laptop_carousel(
  lid INT PRIMARY KEY AUTO_INCREMENT,
  img_url VARCHAR(25),
  title   VARCHAR(255),
  subtitle VARCHAR(255),
  uid     INT
);
INSERT INTO msj_laptop_carousel VALUES(null,'a-1.jpg',"金蒜蒸丝瓜",'富含维生素，清热解暑',1);
INSERT INTO msj_laptop_carousel VALUES(null,'a-2.jpg',"酱蒸排骨",'富含优质蛋白，多吃健脾胃',2);
INSERT INTO msj_laptop_carousel VALUES(null,'a-3.jpg',"黄瓜水晶凉皮",'富含碳水化合物，清凉解暑',3);
INSERT INTO msj_laptop_carousel VALUES(null,'a-4.jpg',"卤肉夹馍",'富含氨基酸，提高免疫力',4);
INSERT INTO msj_laptop_carousel VALUES(null,'a-5.jpg',"西瓜冰粥",'富含氨基酸，解暑生津',5);
INSERT INTO msj_laptop_carousel VALUES(null,'a-6.jpg',"哈密瓜雪糕",'生津止渴，补充维生素',6);


#主页2L商品
CREATE TABLE msj_laptop(
  sid INT PRIMARY KEY AUTO_INCREMENT,
  img_url VARCHAR(128),
  title VARCHAR(128),
  subtitle VARCHAR(128),
  img_uname VARCHAR(128),
  uname VARCHAR(128)
);
INSERT INTO msj_laptop VALUES(null,"01.jpg","小米山药粥","热门 | 最受欢迎的美食","011.jpg","elsa飞雪");
INSERT INTO msj_laptop VALUES(null,"02.jpg","奥尔良烧烤味肉饼","热门 | 吃起来慢慢的幸福感","022.jpg","寓言7656");
INSERT INTO msj_laptop VALUES(null,"03.jpg","甜了个甜甜圈","家常菜 | 好吃又美味","033.jpg","Momo的食摄日记");
INSERT INTO msj_laptop VALUES(null,"04.jpg","香焖猪尾巴","家常菜 | 天涯海角最念得味道","044.jpg","美美家的厨房");
INSERT INTO msj_laptop VALUES(null,"05.jpg","辣根温拌秋葵毛蛤","热门 | 吃起来慢慢的幸福感","055.jpg","踏月色而来～");
INSERT INTO msj_laptop VALUES(null,"06.jpg","烙菜馍","热门 | 最受欢迎的美食","022.jpg","寓言7656");
INSERT INTO msj_laptop VALUES(null,"07.jpg","红烧冰糖猪手",null,"077.jpg","18LS28xgl零落");
INSERT INTO msj_laptop VALUES(null,"08.jpg","核桃糊","热门 | 宝宝营养辅食","088.png","宝宝营养辅食");
INSERT INTO msj_laptop VALUES(null,"09.jpg","肉松皮蛋豆腐","家常菜 | 经典的家常小菜","099.jpg","meggy跳舞的苹果");
INSERT INTO msj_laptop VALUES(null,"10.jpg","自制凉粉","热门 | 冰凉爽滑","1010.jpg","馋.猫");
INSERT INTO msj_laptop VALUES(null,"11.jpg","西芹虾仁","降压 | 降压好菜","1111.png","原味生活家");
INSERT INTO msj_laptop VALUES(null,"12.jpg","腊肠土豆脱糖饭","热门 | 美容养颜，助消化","1212.jpg","风意画");
INSERT INTO msj_laptop VALUES(null,"13.jpg","自制杨梅干",null,"077.jpg","孔老师教做菜");
INSERT INTO msj_laptop VALUES(null,"14.jpg","上汤西兰花","家常菜 | 最受欢迎的美食","044.jpg","美美家的厨房");

#第二个小页面
#主页2L商品
CREATE TABLE msj_laptop_two(
  sid INT PRIMARY KEY AUTO_INCREMENT,
  img_url VARCHAR(128),
  title VARCHAR(128),
  subtitle VARCHAR(128),
  img_uname VARCHAR(128),
  uname VARCHAR(128)
);
INSERT INTO msj_laptop_two VALUES(null,"07.jpg","红烧冰糖猪手",null,"077.jpg","18LS28xgl零落");
INSERT INTO msj_laptop_two VALUES(null,"08.jpg","核桃糊","热门 | 宝宝营养辅食","088.png","宝宝营养辅食");
INSERT INTO msj_laptop_two VALUES(null,"09.jpg","肉松皮蛋豆腐","家常菜 | 经典的家常小菜","099.jpg","meggy跳舞的苹果");
INSERT INTO msj_laptop_two VALUES(null,"10.jpg","自制凉粉","热门 | 冰凉爽滑","1010.jpg","馋.猫");
INSERT INTO msj_laptop_two VALUES(null,"11.jpg","西芹虾仁","降压 | 降压好菜","1111.png","原味生活家");
INSERT INTO msj_laptop_two VALUES(null,"12.jpg","腊肠土豆脱糖饭","热门 | 美容养颜，助消化","1212.jpg","风意画");
INSERT INTO msj_laptop_two VALUES(null,"13.jpg","自制杨梅干",null,"077.jpg","孔老师教做菜");
INSERT INTO msj_laptop_two VALUES(null,"14.jpg","上汤西兰花","家常菜 | 最受欢迎的美食","044.jpg","美美家的厨房");

#第三个小页面
CREATE TABLE msj_laptop_tree(
  sid INT PRIMARY KEY AUTO_INCREMENT,
  img_url VARCHAR(128),
  title VARCHAR(128),
  subtitle VARCHAR(128),
  img_uname VARCHAR(128),
  uname VARCHAR(128)
);

INSERT INTO msj_laptop_tree VALUES(null,"13.jpg","自制杨梅干",null,"077.jpg","孔老师教做菜");
INSERT INTO msj_laptop_tree VALUES(null,"14.jpg","上汤西兰花","家常菜 | 最受欢迎的美食","044.jpg","美美家的厨房");
INSERT INTO msj_laptop_tree VALUES(null,"07.jpg","红烧冰糖猪手",null,"077.jpg","18LS28xgl零落");
INSERT INTO msj_laptop_tree VALUES(null,"08.jpg","核桃糊","热门 | 宝宝营养辅食","088.png","宝宝营养辅食");
INSERT INTO msj_laptop_tree VALUES(null,"09.jpg","肉松皮蛋豆腐","家常菜 | 经典的家常小菜","099.jpg","meggy跳舞的苹果");
INSERT INTO msj_laptop_tree VALUES(null,"10.jpg","自制凉粉","热门 | 冰凉爽滑","1010.jpg","馋.猫");
INSERT INTO msj_laptop_tree VALUES(null,"11.jpg","西芹虾仁","降压 | 降压好菜","1111.png","原味生活家");
INSERT INTO msj_laptop_tree VALUES(null,"12.jpg","腊肠土豆脱糖饭","热门 | 美容养颜，助消化","1212.jpg","风意画");


#第四个小页面
CREATE TABLE msj_laptop_four(
  sid INT PRIMARY KEY AUTO_INCREMENT,
  img_url VARCHAR(128),
  title VARCHAR(128),
  subtitle VARCHAR(128),
  img_uname VARCHAR(128),
  uname VARCHAR(128)
);


INSERT INTO msj_laptop_four VALUES(null,"07.jpg","红烧冰糖猪手",null,"077.jpg","18LS28xgl零落");
INSERT INTO msj_laptop_four VALUES(null,"08.jpg","核桃糊","热门 | 宝宝营养辅食","088.png","宝宝营养辅食");
INSERT INTO msj_laptop_four VALUES(null,"13.jpg","自制杨梅干",null,"077.jpg","孔老师教做菜");
INSERT INTO msj_laptop_four VALUES(null,"14.jpg","上汤西兰花","家常菜 | 最受欢迎的美食","044.jpg","美美家的厨房");
INSERT INTO msj_laptop_four VALUES(null,"09.jpg","肉松皮蛋豆腐","家常菜 | 经典的家常小菜","099.jpg","meggy跳舞的苹果");
INSERT INTO msj_laptop_four VALUES(null,"12.jpg","腊肠土豆脱糖饭","热门 | 美容养颜，助消化","1212.jpg","风意画");
INSERT INTO msj_laptop_four VALUES(null,"10.jpg","自制凉粉","热门 | 冰凉爽滑","1010.jpg","馋.猫");
INSERT INTO msj_laptop_four VALUES(null,"11.jpg","西芹虾仁","降压 | 降压好菜","1111.png","原味生活家");

#第五个小页面
CREATE TABLE msj_laptop_five(
  sid INT PRIMARY KEY AUTO_INCREMENT,
  img_url VARCHAR(128),
  title VARCHAR(128),
  subtitle VARCHAR(128),
  img_uname VARCHAR(128),
  uname VARCHAR(128)
);


INSERT INTO msj_laptop_five VALUES(null,"14.jpg","上汤西兰花","家常菜 | 最受欢迎的美食","044.jpg","美美家的厨房");
INSERT INTO msj_laptop_five VALUES(null,"07.jpg","红烧冰糖猪手",null,"077.jpg","18LS28xgl零落");
INSERT INTO msj_laptop_five VALUES(null,"08.jpg","核桃糊","热门 | 宝宝营养辅食","088.png","宝宝营养辅食");
INSERT INTO msj_laptop_five VALUES(null,"09.jpg","肉松皮蛋豆腐","家常菜 | 经典的家常小菜","099.jpg","meggy跳舞的苹果");
INSERT INTO msj_laptop_five VALUES(null,"10.jpg","自制凉粉","热门 | 冰凉爽滑","1010.jpg","馋.猫");
INSERT INTO msj_laptop_five VALUES(null,"13.jpg","自制杨梅干",null,"077.jpg","孔老师教做菜");
INSERT INTO msj_laptop_five VALUES(null,"12.jpg","腊肠土豆脱糖饭","热门 | 美容养颜，助消化","1212.jpg","风意画");
INSERT INTO msj_laptop_five VALUES(null,"11.jpg","西芹虾仁","降压 | 降压好菜","1111.png","原味生活家");

#contast
#轮播图
CREATE TABLE msj_contast_carousel(
  lid INT PRIMARY KEY AUTO_INCREMENT,
  img_url VARCHAR(125),
  uid     INT
);
INSERT INTO msj_contast_carousel VALUES(null,'download.jpg',1);
INSERT INTO msj_contast_carousel VALUES(null,'chirou.jpg',2);
INSERT INTO msj_contast_carousel VALUES(null,'download1.jpg',3);
INSERT INTO msj_contast_carousel VALUES(null,'hongbei.jpg',4);
INSERT INTO msj_contast_carousel VALUES(null,'huoguo.jpg',5);
INSERT INTO msj_contast_carousel VALUES(null,'meishijgushi.jpg',6);
INSERT INTO msj_contast_carousel VALUES(null,'meishiriji.jpg',6);

#contast 2L
CREATE TABLE msj_contast_2L(
  uid INT PRIMARY KEY AUTO_INCREMENT,
  img_uname VARCHAR(128),
  uname VARCHAR(128),
  utime VARCHAR(128),
  title VARCHAR(128),
  img1_url VARCHAR(128),
  img2_url VARCHAR(128),
  img3_url VARCHAR(128),
  img4_url VARCHAR(128),
  img5_url VARCHAR(128),
  img6_url VARCHAR(128),
  img_word VARCHAR(128),
  word INT,
  img_collect VARCHAR(128),
  collect INT
);
INSERT INTO msj_contast_2L VALUES(null,"a.jpg","蛋蛋妈的厨房","2018-11-28发布","好几天忘记拍照了😄","a-1.jpg","a-2.jpg","a-3.jpg","a-4.jpg","a-5.jpg",null,"comment24@3x.png",23,"heart24@3x.png",350);
INSERT INTO msj_contast_2L VALUES(null,"b.jpg","一一描","2018-11-28发布","超柔软湿润—淡奶油磅蛋糕 做过各式各样的磅蛋糕 但是最爱的还是这款淡奶油磅蛋糕 加了淡奶油的磅蛋糕奶香味更浓郁 翻倍的鸡蛋让蛋糕体更湿润 完全不需要再刷糖水 这又是让自己长肉的节奏","b-1.jpg","b-2.jpg","b-3.jpg","b-4.jpg",null,null,"comment24@3x.png",3,"heart24@3x.png",114);
INSERT INTO msj_contast_2L VALUES(null,"c.jpg","Betterme艳","2018-11-27发布","想念家乡的泡萝卜，今天动手做了.","c-1.jpg","c-2.jpg","c-3.jpg","c-4.jpg",null,null,"comment24@3x.png",0,"heart24@3x.png",92);
INSERT INTO msj_contast_2L VALUES(null,"d.jpg","黄根","2018-11-26发布","潮汕拜神","d-1.jpg","d-2.jpg","d-3.jpg",null,null,null,"comment24@3x.png",0,"heart24@3x.png",58);
INSERT INTO msj_contast_2L VALUES(null,"e.jpg","特能吃的简单","2019-1-26发布","炒方便面 小家伙吃的真香 🍝","e-1.jpg","e-2.jpg",null,null,null,null,"comment24@3x.png",0,"heart24@3x.png",80);
INSERT INTO msj_contast_2L VALUES(null,"f.jpg","大薇薇卍","2019-1-22发布","妈妈每天做的午餐。","f-1.jpg","f-2.jpg","f-3.jpg",null,null,null,"comment24@3x.png",0,"heart24@3x.png",104);
INSERT INTO msj_contast_2L VALUES(null,"g.jpg","茉莉花1152","2018-11-24发布","生活就是一只看不见的储蓄罐， 你投入的每一份努力都不会白费。 你若成功了，吃青菜那叫养生， 你若失败了，吃青菜那叫寒酸， 这不是鸡汤，这是现实。 ​ 感恩亲哥带来家乡的潮州卤水， 感恩爸爸的月季飘香，好美！ 感恩妈妈一手好厨艺..... 感恩...有你们真好！节日快乐！","g-1.jpg","g-2.jpg","g-3.jpg","g-4.jpg","g-5.jpg","g-6.jpg","comment24@3x.png",3,"heart24@3x.png",52);

# contast2L 最热
CREATE TABLE msj_contast2_2L(
  uid INT PRIMARY KEY AUTO_INCREMENT,
  img_uname VARCHAR(128),
  uname VARCHAR(128),
  utime VARCHAR(128),
  title VARCHAR(128),
  img1_url VARCHAR(128),
  img2_url VARCHAR(128),
  img3_url VARCHAR(128),
  img4_url VARCHAR(128),
  img5_url VARCHAR(128),
  img6_url VARCHAR(128),
  img_word VARCHAR(128),
  word INT,
  img_collect VARCHAR(128),
  collect INT
);
INSERT INTO msj_contast2_2L VALUES(null,"b.jpg","一一描","2018-11-28发布","超柔软湿润—淡奶油磅蛋糕 做过各式各样的磅蛋糕 但是最爱的还是这款淡奶油磅蛋糕 加了淡奶油的磅蛋糕奶香味更浓郁 翻倍的鸡蛋让蛋糕体更湿润 完全不需要再刷糖水 这又是让自己长肉的节奏","b-1.jpg","b-2.jpg","b-3.jpg","b-4.jpg",null,null,"comment24@3x.png",3,"heart24@3x.png",114);
INSERT INTO msj_contast2_2L VALUES(null,"a.jpg","蛋蛋妈的厨房","2018-11-28发布","好几天忘记拍照了😄","a-1.jpg","a-2.jpg","a-3.jpg","a-4.jpg","a-5.jpg",null,"comment24@3x.png",23,"heart24@3x.png",350);
INSERT INTO msj_contast2_2L VALUES(null,"f.jpg","大薇薇卍","2019-1-22发布","妈妈每天做的午餐。","f-1.jpg","f-2.jpg","f-3.jpg",null,null,null,"comment24@3x.png",0,"heart24@3x.png",104);
INSERT INTO msj_contast2_2L VALUES(null,"c.jpg","Betterme艳","2018-11-27发布","想念家乡的泡萝卜，今天动手做了.","c-1.jpg","c-2.jpg","c-3.jpg","c-4.jpg",null,null,"comment24@3x.png",0,"heart24@3x.png",92);
INSERT INTO msj_contast2_2L VALUES(null,"d.jpg","黄根","2018-11-26发布","潮汕拜神","d-1.jpg","d-2.jpg","d-3.jpg",null,null,null,"comment24@3x.png",0,"heart24@3x.png",58);
INSERT INTO msj_contast2_2L VALUES(null,"g.jpg","茉莉花1152","2018-11-24发布","生活就是一只看不见的储蓄罐， 你投入的每一份努力都不会白费。 你若成功了，吃青菜那叫养生， 你若失败了，吃青菜那叫寒酸， 这不是鸡汤，这是现实。 ​ 感恩亲哥带来家乡的潮州卤水， 感恩爸爸的月季飘香，好美！ 感恩妈妈一手好厨艺..... 感恩...有你们真好！节日快乐！","g-1.jpg","g-2.jpg","g-3.jpg","g-4.jpg","g-5.jpg","g-6.jpg","comment24@3x.png",3,"heart24@3x.png",52);
INSERT INTO msj_contast2_2L VALUES(null,"e.jpg","特能吃的简单","2019-1-26发布","炒方便面 小家伙吃的真香 🍝","e-1.jpg","e-2.jpg",null,null,null,null,"comment24@3x.png",0,"heart24@3x.png",80);
# find2L 最热
CREATE TABLE msj_find_2L(
  uid INT PRIMARY KEY AUTO_INCREMENT,
  header VARCHAR(128),
  tally   VARCHAR(128),
  img_url VARCHAR(128),
  uname VARCHAR(128),
  img1 VARCHAR(128),
  img2 VARCHAR(128),
  img3 VARCHAR(128),
  img4 VARCHAR(128),
  img5 VARCHAR(128),
  img_word VARCHAR(128),
  word VARCHAR(128),
  img_collect VARCHAR(128),
  collect VARCHAR(128)
);
INSERT INTO msj_find_2L VALUES(null,"昨日全国收藏最高","收藏最多","a-1.jpg","青蒜炒牛肚","xin.png","xin.png","xin.png","xin.png","xin.png","shi.png","6步 / <5分钟","kou.png","香辣味 / 炒");
INSERT INTO msj_find_2L VALUES(null,"全国最爱搜蒜蓉粉丝蒸娃娃菜","搜索最多","b-1.jpg","蒜蓉粉丝蒸娃娃菜","xin.png","xin.png","xin.png","xin.png","xin.png","shi.png","9步 / <30分钟","kou.png","家常味 / 蒸");
INSERT INTO msj_find_2L VALUES(null,"昨日全国最爱菜谱","点击最多","c-1.jpg","牛肉火锅","xin.png","xin.png","xin.png","xin.png","xin.png","shi.png","12步 / <60分钟","kou.png","香辣味 / 炖");
INSERT INTO msj_find_2L VALUES(null,"昨日全国最高评论","评论最高","d-1.jpg","芝麻鸡蛋薄脆饼干","xin.png","xin.png","xin.png",null,null,"shi.png","6步 / <30分钟","kou.png","家常味 / 烤");
INSERT INTO msj_find_2L VALUES(null,"全国现在最关注的菜谱","点击最多","e-1.jpg","酸辣土豆丝","xin.png","xin.png","xin.png","xin.png","xin.png","shi.png","12步 / <5分钟","kou.png","酸辣味 / 炒");
INSERT INTO msj_find_2L VALUES(null,"全国最爱收藏的菜谱","收藏最多","f-1.jpg","葱花千层饼","xin.png","xin.png","xin.png",null,null,"shi.png","7步 / <5分钟","kou.png","家常味 / 烙");
INSERT INTO msj_find_2L VALUES(null,"昨日全国最爱搜索:肋排蒸芋头","收藏最多","g-1.jpg","荤素搭配肋排蒸娃娃菜","xin.png","xin.png","xin.png",null,null,"shi.png","5步 / <30分钟","kou.png","家常味 / 蒸");
INSERT INTO msj_find_2L VALUES(null,"昨日成都市最高评论","评论最高","g-2.jpg","牛肉肠葱花饼","xin.png","xin.png","xin.png",null,null,"shi.png","11步 / <30分钟","kou.png","葱香味 / 烙");
INSERT INTO msj_find_2L VALUES(null,"全国议论最多的菜谱","评论最高","g-3.jpg","素炒菜花","xin.png","xin.png","xin.png",null,null,"shi.png","7步 / <10分钟","kou.png","家常味 / 炒");
INSERT INTO msj_find_2L VALUES(null,"昨日四川省最高评论","评论最高","g-4.jpg","蒸蛋羹","xin.png","xin.png","xin.png",null,null,"shi.png","12步 / <15分钟","kou.png","咸鲜味 / 蒸");

# 详情页 第一部分
CREATE TABLE msj_particular(
  uid INT PRIMARY KEY AUTO_INCREMENT,
  img_url VARCHAR(128),
  title VARCHAR(128),
  collect  VARCHAR(128),
  browse VARCHAR(128),
  img_name VARCHAR(128),
  uname VARCHAR(128),
  issue VARCHAR(128),
  concern VARCHAR(128),
  #内容
  details VARCHAR(300),
  grade VARCHAR(10),
  img1 VARCHAR(128),
  img_word VARCHAR(128),
  word VARCHAR(128),
  img_coll VARCHAR(128),
  coll VARCHAR(128),
  img_utime VARCHAR(128),
  utime VARCHAR(128),
  main VARCHAR(10),
  main_1 VARCHAR(128),
  fu VARCHAR(10),
  fu_1 VARCHAR(128)
);
INSERT INTO msj_particular VALUES(null,"01.jpg","小米山药粥","170人收藏","7527人浏览","02.jpg","elsa飞雪","发布212篇菜谱","关注","匆忙的工作日早餐总是来不及，苏泊尔电压力锅预约功能，一键帮你搞定早餐，起床就可以喝上香喷喷的的小米粥啦","评分","xin.png","chu.png","煮","kou.png","家常味","shi.png","<30分钟","主料","小米半杯、山药100克","辅料","糖适量");

# 详情页 第二部分
CREATE TABLE msj_particular_step(
  uid INT PRIMARY KEY AUTO_INCREMENT,
  step01 VARCHAR(128),
  img_step01 VARCHAR(128),
  step01_content VARCHAR(128),
  step02  VARCHAR(128),
  img_step02 VARCHAR(128),
  step02_content VARCHAR(128),
  step03  VARCHAR(128),
  img_step03 VARCHAR(128),
  step03_content VARCHAR(128),
  step04  VARCHAR(128),
  img_step04 VARCHAR(128),
  step04_content VARCHAR(128),
  step05  VARCHAR(128),
  img_step05 VARCHAR(128),
  step05_content VARCHAR(128),
  step06  VARCHAR(128),
  img_step06 VARCHAR(128),
  step06_content VARCHAR(128),
  product_title VARCHAR(128),
  product_1 VARCHAR(128),
  product_2 VARCHAR(128),
  product_3 VARCHAR(128),
  product_4 VARCHAR(128)
);
INSERT INTO msj_particular_step VALUES(null,"小米山药粥步骤1","03.jpg","晚上睡觉前将小米淘洗干净","步骤2","04.jpg","将山药去皮洗净切成小的滚刀块","步骤3","05.jpg","将小米和山药加入到电压力锅中，加入水","步骤4","06.jpg","设定好烹饪时间后再次设定预约时间","步骤5","07.jpg","早晨烹饪结束后自动调到保温功能","步骤6","08.jpg","香浓的小米粥已经熬好了","小米山药粥成品图","09.jpg","10.jpg","11.jpg","12.jpg");
