//1:引入第三方模块
const express = require("express");
const mysql = require("mysql");
const cors = require("cors");
const session = require("express-session");
//2:配置第三方模块
 //2.1:配置连接池
 var pool = mysql.createPool({
   host:"127.0.0.1",
   user:"root",
   password:"",
   port:3306,
   database:"msj",
   connectionLimit:15
 })
 //2.2:跨域
 var server = express();
 server.use(cors({
   origin:["http://127.0.0.1:8080",
   "http://localhost:8080"],
   credentials:true
 }))
 //2.3:session
 server.use(session({
   secret:"128位字符串",
   resave:true,
   saveUninitialized:true
 }))
// 2.9 指定静态目录
server.use(express.static("public"))

 server.listen(3000);
//3:完成第一个功能用户登录
server.get("/login",(req,res)=>{
  //1:参数
  var uname = req.query.uname;
  var upwd = req.query.upwd;
  //1.1:正则表达式验证用户名或密码
  //2:sql
var sql = "SELECT id FROM ";
sql +=" msj_login WHERE uname = ?";
sql +=" AND upwd = md5(?)";
  //3:json
  pool.query(sql,[uname,upwd],(err,result)=>{
      if(err)throw err;
      if(result.length==0){
         res.send({code:-1,msg:"用户名或密码有误"});
      }else{
        //将当前登录用户uid保存 session对象
        // result=[{id:1}]
        req.session.uid=result[0].id; 
         //??缺少一步
         res.send({code:1,msg:"登录成功"});
      }
  })
})
// 3.完成轮播图插入

//4:完成第二个功能:商品分页显示
// 第一个小页面
server.get("/product",(req,res)=>{
  //-参数
  var pno = req.query.pno;
  var ps = req.query.pageSize;
  // -设置默认值
  if(!pno){pno=1}
  if(!ps){ps=6}
  //-创建第一条 sql语句 当前页
  var obj = {code:1,msg:"查询成功"};
  var sql = "SELECT sid,img_url,title,subtitle,img_uname,uname FROM msj_laptop LIMIT ?,?";
  var off = (pno-1)*ps;
  ps = parseInt(ps);
  pool.query(sql,[off,ps],(err,result)=>{
      if(err)throw err;
      obj.data = result;
      var sql = "SELECT count(*) AS c FROM msj_laptop";
      pool.query(sql,(err,result)=>{
        if(err)throw err;
        var pc = Math.ceil(result[0].c/ps);
        obj.pc = pc;
        res.send(obj);
      })
  });
});  
// 5.第二个小页面
server.get("/product_two",(req,res)=>{
  //-参数
  var pno = req.query.pno;
  var ps = req.query.pageSize;
  // -设置默认值
  if(!pno){pno=1}
  if(!ps){ps=6}
  //-创建第一条 sql语句 当前页
  var obj = {code:1,msg:"查询成功"};
  var sql = "SELECT sid,img_url,title,subtitle,img_uname,uname FROM msj_laptop_two LIMIT ?,?";
  var off = (pno-1)*ps;
  ps = parseInt(ps);
  pool.query(sql,[off,ps],(err,result)=>{
      if(err)throw err;
      obj.data = result;
      var sql = "SELECT count(*) AS c FROM msj_laptop_two";
      pool.query(sql,(err,result)=>{
        if(err)throw err;
        var pc = Math.ceil(result[0].c/ps);
        obj.pc = pc;
        res.send(obj);
      })
  });
});  
// 6.第三个小页面
server.get("/product_tree",(req,res)=>{
  //-参数
  var pno = req.query.pno;
  var ps = req.query.pageSize;
  // -设置默认值
  if(!pno){pno=1}
  if(!ps){ps=6}
  //-创建第一条 sql语句 当前页
  var obj = {code:1,msg:"查询成功"};
  var sql = "SELECT sid,img_url,title,subtitle,img_uname,uname FROM msj_laptop_tree LIMIT ?,?";
  var off = (pno-1)*ps;
  ps = parseInt(ps);
  pool.query(sql,[off,ps],(err,result)=>{
      if(err)throw err;
      obj.data = result;
      var sql = "SELECT count(*) AS c FROM msj_laptop_tree";
      pool.query(sql,(err,result)=>{
        if(err)throw err;
        var pc = Math.ceil(result[0].c/ps);
        obj.pc = pc;
        res.send(obj);
      })
  });
});  
// 7.第四个小页面
server.get("/product_four",(req,res)=>{
  //-参数
  var pno = req.query.pno;
  var ps = req.query.pageSize;
  // -设置默认值
  if(!pno){pno=1}
  if(!ps){ps=6}
  //-创建第一条 sql语句 当前页
  var obj = {code:1,msg:"查询成功"};
  var sql = "SELECT sid,img_url,title,subtitle,img_uname,uname FROM msj_laptop_four LIMIT ?,?";
  var off = (pno-1)*ps;
  ps = parseInt(ps);
  pool.query(sql,[off,ps],(err,result)=>{
      if(err)throw err;
      obj.data = result;
      var sql = "SELECT count(*) AS c FROM msj_laptop_four";
      pool.query(sql,(err,result)=>{
        if(err)throw err;
        var pc = Math.ceil(result[0].c/ps);
        obj.pc = pc;
        res.send(obj);
      })
  });
}); 
// 7.第五个小页面
server.get("/product_five",(req,res)=>{
  //-参数
  var pno = req.query.pno;
  var ps = req.query.pageSize;
  // -设置默认值
  if(!pno){pno=1}
  if(!ps){ps=6}
  //-创建第一条 sql语句 当前页
  var obj = {code:1,msg:"查询成功"};
  var sql = "SELECT sid,img_url,title,subtitle,img_uname,uname FROM msj_laptop_five LIMIT ?,?";
  var off = (pno-1)*ps;
  ps = parseInt(ps);
  pool.query(sql,[off,ps],(err,result)=>{
      if(err)throw err;
      obj.data = result;
      var sql = "SELECT count(*) AS c FROM msj_laptop_five";
      pool.query(sql,(err,result)=>{
        if(err)throw err;
        var pc = Math.ceil(result[0].c/ps);
        obj.pc = pc;
        res.send(obj);
      })
  });
}); 
// contast 轮播图
server.get("/contast",(req,res)=>{
  var sql ="SELECT lid,img_url FROM msj_contast_carousel";
  pool.query(sql,(err,result)=>{
    if(err) throw err;
    res.send(result)
  })
})
// contast 2L
server.get("/contast2",(req,res)=>{
   var sql = "SELECT uid,img_uname,uname,utime,title,img1_url,img2_url,img3_url,img4_url,img5_url,img6_url,img_word,word,img_collect,collect FROM msj_contast_2L";
   pool.query(sql,(err,result)=>{
     if(err) throw err;
     res.send(result)
   })
})
// contast2 2L
server.get("/contast3",(req,res)=>{
  var sql="SELECT uid,img_uname,uname,utime,title,img1_url,img2_url,img3_url,img4_url,img5_url,img6_url,img_word,word,img_collect,collect FROM msj_contast2_2L";
  pool.query(sql,(err,result)=>{
    if(err) throw err;
    res.send(result)
  })
})
// find 2L
server.get("/find2",(req,res)=>{
  var sql="SELECT uid,header,tally,img_url,uname,img1,img2,img3,img4,img5,img_word,word,img_collect,collect FROM msj_find_2L";
  pool.query(sql,(err,result)=>{
    if(err) throw err;
    res.send(result)
  })

})

// particular 详情页 第一部分
server.get("/particular",(req,res)=>{
  var sql = "SELECT uid,img_url,title,collect,browse,img_name,uname,issue,concern,details,grade,img1,img_word,word,img_coll,coll,img_utime,utime,main,main_1,fu,fu_1 FROM msj_particular";
  pool.query(sql,(err,result)=>{
    if(err) throw err;
    res.send(result)
  })
})

// particular 详情页 第二部分
server.get("/particular_2",(req,res)=>{
  var sql="SELECT uid,step01,img_step01,step01_content,step02,img_step02,step02_content,step03,img_step03,step03_content,step04,img_step04,step04_content,step05,img_step05,step05_content,step06,img_step06,step06_content,product_title,product_1,product_2,product_3,product_4 FROM msj_particular_step";
  pool.query(sql,(err,result)=>{
    if(err) throw err;
    res.send(result)
  })
})